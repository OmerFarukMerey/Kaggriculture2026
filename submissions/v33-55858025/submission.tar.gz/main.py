"""v43: climb-safe common opening with two observable shop branches."""

import base64
import json
import sys
import types
import zlib


def _v43_package(name):
    module = sys.modules.get(name)
    if module is None:
        module = types.ModuleType(name)
        module.__file__ = "<bundled-package:" + name + ">"
        module.__package__ = name
        module.__path__ = []
        sys.modules[name] = module
    return module


def _v43_load(name, source):
    parent, _, child = name.rpartition(".")
    if parent:
        _v43_package(parent)
    module = types.ModuleType(name)
    module.__file__ = "<bundled:" + name + ">"
    module.__package__ = parent
    sys.modules[name] = module
    exec(compile(source, module.__file__, "exec"), module.__dict__)
    if parent:
        setattr(sys.modules[parent], child, module)
    return module


_V43_MODULES = json.loads(zlib.decompress(base64.b85decode(
(
    'c-rlKiFO-DlHjkD<(=1n1V8}gtJ#L%(lTx9Su(YhJiQ(g4=w@)vPNJPTm?v?wfy&uBag_V3IJu#?99?LZ4;H5k#|I7oF5+4vnpS$'
    '>%rTD(X=Wz>uh?RU6<9(w9e9McJ<)!!J;a!lj(G^S#PRrI!*HHRavc*v?$7Ty3Wg@J}=a_S-HA7FJ2zKdX<cm59bdSX?2}d=MN5('
    'v-1b|`TW78mz+PiN{e|-'
    'pXujyTD{5E{QLI2m}iTm%2vztX1Xeu`Rt~X&ZwX6;dzn3KUhJPlo#eJ{!_2B6?A=_7oF?$eP`H9@?wpZ2AA2obN&F!&mZ)XVK*r&'
    '_;<ILEVIJEPx{HIYoS#cOu3+04dz+4!asD~GXyn3C^#?GNHyTGofi*!58jUcK3!)O3@BZ~TAtJYom|ve^_JGIUlz-oMAt~lw^;@A'
    'u9Hoj&65i#xyllNk)#((s-N(-49<)5;x&}P!Y{Mytl*tU@){=$KjBBZ1jsq8<|>1K73-'
    'v2z^2`(rA^jVI?D!0@(i{u1!(W8bOl{~)l1T3wy7#;(Z9~tX>y&-'
    '%Y5F$siv^yS6P*;HWx5MSeRm6mCNK^zP^H^le{U)cX@G%gFY|H)v7G8+Z;R3*Ecw3UI6HAmqX<pEA`_#U0-'
    '3@dGYG_`SYW1pC7}9cX<8JAG~^fdi2k4k55m3#ce)+@Z$LS$<OM~XU~7)zy5i0@|^!V{^1AsLpOeX^5W?A370%QIz2skt?K`He5C'
    '&T{`mCuv**wL?f8`1!M?vdJ^AjJr?02q{yIJS`Pqx3=X~^^p8OLJwCwiPkH^O^`J)}d4<{$Dj`<@E2G0Kv&wqJ6{pazsAAWpIup('
    '1COb!M^Gj27>!{o`}3;U7!bt`hWSnt4mqh1e_(ctr79q{WD^Hr}1eia~jZQPG?m2?SA?8VXlo}Qe3cYKQIVKjst{PFm^>C>Z^M^B'
    '%<{*}HBd28{8Pm9g<MOJm*rpry%!%LrTmh16wFw{4GUELhY+gd|8Kv^uybj{7wz0BUvvei22yuMjw$5mBUz2sl9nEvh_1~*>y<y>'
    'k7K3~uY9OU&PFY<NP;qTofTh^IvXeLo#W%Fq|n`L#~xhT_WKCSaVGTrA@x?I4BZ9($*adP1F`@xQ`L)8IC^%DJ8x91hN6xo&yt@P'
    '(xJN|T;Ulvos*9!9iBCt4@FZ7FaJ-Z@QwanjU3D$-?yMeo}F+-'
    'JIr>m914GC;bK2O(x;Z{|)$lnh%UO<p=*>flvN6{`Kp%1reR}qZ?GJ<1+yW%2xE|aJ}8DmA-r6IRR>QqB>+lszmqq7OMI-'
    'A&<c(Abej6qMZPc?$CiHK0CItL$a^}$<Zvo%czt56*^2i2t_g`&%@J{nMf?ecov;YD$qxYc1a*aMYyVMMxTak!~$ki7@`Fz=jMik'
    'vI}5TIZ<<7si3b<Cjq0%TWr#6vl=#C;MSq%P%An!bD>YAy)ljDVEY99GnALj&Xj7$h}0JJh3`Ogxa9oA6+IP~6e#HhN7b&K2aU_E'
    'M~>^53a%y4`r{fN0YBbnnGWt_Q1l3AFvY)03BvUp_y2dJJe{Ro3|$n!UTq;p$}Xvl*~n$wdZZ%;=8rh@6}8U*Np2svP*5%;`jZ!*'
    '1Z%^Xb>M)jC=-'
    'hyT3EZVnT{z7Zx@{F<$Wy9qUW2^Yhb&hy#2qk7Z)9_)|Pad!YX`?~IQ4W^^ZQ@jNprL6MI+&CAGs1UoWw42DZ;E}_1@h$<hfVm7O'
    'z-'
    '~V5i1NtgS397%OoYdOh7j%jK&VbF4?`%J>wHP`69b@6kpmzI5@Rl^NL5BdJwl{uP~1e~@V4lULN@e$FWCUaoGMHX8<qiu&nj4DpT'
    'SoMjant&@CeKr(<q!Gu{#n1V+G(ni%n*~YB(@*1M-Z(O`Ohw5e0TSFY0w#%ret`FX`a<=q2k7aNb=Sj2s@~-h-'
    '`!fVH@R0pRJ@4bSL!IA2DSt}~<#HtX`p3cUf)KYr*8lds1B^lQ0YNQmkCd-?tBX42ihPM;>Pa+o-'
    '5(q&#`$O#?{zU(Eq*%Flj`%^C8!nqQ->-ovkpN_xlV`mcH<p$0Myf|K8RautIV9P2%iwLl<=E5iRB7+{2WjT9;Zy?|vQh-}S*-'
    '}Ddq>8&UN4~;dK|F6T3cyO`3Qre)9JFn%IF&uR{9V1MqGaoO=|gzqBD38QS_@JW2V5Q1C^i!qP0dtH0L~YZg!2cudBB#t9czk2hf'
    '+->1fDG$VA5GQe?SKg&zY#x#ars%2!sq>Nl>GSTLsSoRM98)?7df>!h<kfPV05Gnc*YSdv*bCeErMmaq#kTzKh4#(-'
    'T~kTf&PtI&Wj}_PJl8V}SQJo|~WH<r}L#m&Xog)}#IH#_M7Qg{R-Zt|LB&#rFG*w>^Kr^<YmFx^QnJ{^R3-'
    '__+=rTK2K@`zEWIeB-f}yLkZgM6sm)S$M)M!^j1=^AoLoq~aWRXdio07-U9Fm{uQiz2(R|b-'
    'O+1yw};*i%;~8n*Y8@Nzy_0Rt>~!UX>*td^H~T{o7CK&2`5xMFYYCaQ}QHp+M8Rdy+0Q0xjLb{=%bdAVk*H^nZqvLMGadNUl`!$b'
    'xaDU%I+wn6)fu3QT)h!=dd2Z^&an@Yl#XzJ)7t0axG1#OlpzwY)J;Ni9yoDQb2TZWOR;|2e#}k#lK&c?26NcxJ&WBO(mmhqNAuyl'
    '`O;li^@!P86OaE#$hj%v4prqZf?n*?CZgEZw1dRtd4<V-'
    'LYBBu0WSngG%$&)~!4FgQIP`4o6;=W9BvN|e(A66**ohhG^n1Fq{1VBfQ<6P{jbjO?RYyhyLQ=nU&ll1F^wP!MIrN}}JJJX_AEh^'
    'J~k75<H5TpA8o<Jk5g!-'
    'bdwu7>7;tdQU^lyIJ^UEB0j6`CQ;4(=o&gS*ZXIu+FySp~m<m9M7h+caOMa4oUj_bD8XZriY237{UGgC%rbAu403GCUqGixepvT^'
    'rpG$&>2HLva{93F&gUqjO}qQnV{YzD=@Y9~AKzf~^poM9=3in5`fo^6~L^4lwr#Dlc{@CHgOMsc{?&JYu{7;yTNFqF9*-'
    'ROWfTOGW_O@0Xf^VVU`;L^`nN=!`1!!Hn0tsIv5pb7IAj+Fh2{+uCST@JnY3w0m9w`EG_lPtJ~-'
    '0UY#+Jn?l|0nJsVUEQo}@7HVz)M7f%)eZ{^ygRXT>6!b|Rm;TEcNCc{V9U68nJp0g#cz0xFJHCN`Q=qxMe`sIw<Nu&JJ=0AN%{=P'
    '!o`0c0pt15RvX!BBexndVOTAN3KuLjOnb=%uJIrFid!E{da5xny4_%@HSaQIDV~%NLc7f}8^i4=mvAfL3oi4+9;@YM+4yy}$z0ax'
    'RkmCv+1m`BmR4e>F#kW2*;QHMTNeeJ_z)(|TFDwl<fB5~NC{xZjlzAdMlbzwo3PW!{AL+5-'
    '1Y!zfvO{VGxES0BQskRa6@s9QCEXA3{zFBt0i`h1k4xcdM)9ey>V#?tsfkPLl!N0>^+OGjPTeBuDr3h@*06psj0@p`jxEY()1?6Z'
    '#)M5rbf<BZ`rLDrUCLMq2NTw);vy8TuJjB7)$X3?xV}f`=SUKyJ`CMI2mpis^Oj{5iW~2Tl6-9M+wyMdc!-'
    'xvnIqGh$re<Nymcwd1yxGi6$%<y)TWB`p#Jp1H_HdONoyh{r7+l0m}y3pNP7Ph`^x3OqxE_au)`HFbMy7m<VmKTt=uKt4#|OD<Gx'
    'ivb-Fv%p=hQAPpbjlnv4q8V+<iG@V}3k1a&cd-'
    '>`q5CEh|oeB|Gt<ai6EP&7G5TEHo?t@V(sUH4+__RjgmL4g*DfU2#AY4rlb$WJaRnU`wa&bF-'
    ')6yky0P~wTmT=L7#S1Pr`0J2C&@)ZXm7XI|A3Y&>y9D036)cYep{Hv^&b%gvzUap3L?0ZUkoS;c0E2X{$}RDY?wSWWvVXzesmH{1'
    '`8J!b%Xeut7qa_xTEQIx3dRC*H4!C^*VW9?!da^pA)jOQFG{;Y6_rTF^aIS<c$r>b%u@gl$oDWI-'
    'h%#SR^>e+8T*a+k{h^K`ltSDXc&z(jF)ga_oCiMC<jNSx+D+yo<q_9dog@l(cEx+oV=n3(R;QLF!z`Ne6t<E@sS4bC;)&;iJNTze'
    'm*&U{UbrZ%|P=72f{boA-'
    'p>IML>9DAp~kHaeuUipqCWTtRVbip}QA~G${qHCqXpImEuNzVu5vWGdU~XPm)jY^0Gc8AVvBhnL)TmS{^WctgnG7TIYWtV`t3D_('
    'AXTm}s2lGLa{MhO2xIj3OGGVH2ZcTwkSR1I9WQ=ss1}9K-'
    '=$+^|*Mm!q%l!bQTmQFDbsI$w^y>>;d()s4Qx|1EXhdnjKu=E36jRf_9i?Lq&`)YBiUFc-'
    'zzAmziYZ-=5-R!{lc4^+NJj3qP;f1c(%P-1tg^xf2w6r)Gzx-SEKE1F^V5@*1NZR$uDd|cZs>+Gg+7HaPfUMC5`s-'
    'B&%qlx55;aQK*L3|xIs4{7hj1;D06{70-'
    'XY?6?9^9q8aqXYMz&q=>`MSEgI4%BAbQ<X{(!APGVWd6v4bP>9;ng=**Y21G6W4jof`7LU<h^jQzJYP!=*-'
    'd^Kmj3;z|ORacH+Hm*tmHN*z-'
    '%~8f7PTVt@);;Ww~GJTlE0d0l%?88H%HP_Bjrg~PBYT#2yGE*es*2dA%1wyh|`H*y@^Z43Y7(doYuE9BaO$a+G>>p_#~N2}?_vaN'
    'YqXjWI6&^fJ#6R)PQlXEJL4%_+Q6m@4)Wme8S!bMtV#@yk$oO{xyBht3P?2;nA2KsL-'
    '&$R+>24lI@rkrRszCtbmfGWFphfB}~`8yfow=fpYpdIc4XMpGF0}xcr5!u&2N{-'
    'EEC0lU52{GJl@P@>Z@56DqEDv3fuUuR&MmswgPMLf4hGa*7>zyz&s#XD`lzv#bB5Q5DdriZk2d2MBckJ0Lu_Mmh-mBP#JNE3zQ@8'
    'fcTL33Jn>r2kH<Fb%oDH@=`X0y9XN~u!f=f{YFNBEcDzD(L8M!i`Uqc1A5AH|t21fOcEufCpJ~T3(PV2QY1trO?5^v&JGBd)8*K`'
    '$GBJ9Jl0%DX15EwkHc=cw>4OvRnaIJaV!i=k4m$Ns6zh>pVJ@*%#7L6{<H{;}suZFQ(c$X2#10NlNzsLSS=yybGg3QLjUopxC9F9'
    '0vdqVMlT)eI8tXMoBds&54K=@B7Xhy`$Z4^ZEVlqx*_ufqR-c0x2O!wYQ_ufqR-c0x2O!wYQ_ufqR-c0x2O!wYQ_ufqR-'
    'c0x2O!wYQ_ufqR-c0x2O!wYQ_ufqR-c0x2O!wYQ_ufqR-c0x2O!wYQ_ufqR-c0x2O!wYQ_ufqR-c0x2O!wYQ_ufqR-'
    'c0x2O!wYQ_ufqR-c0x2O!wYQ_ufqR-c0x2O!wYQ_ufqR-'
    'c0x2O!wYQ|1sW72M20yQ#jZ#&IgANKK<nJrmh}e<i+Exc$=(lfJzikw6D(z3VHf<y3ohD&keQjkTKUw0Cw_IdU;vpv(1u>sp|D+e'
    'q%hHl+V%IgVA7=q?bsFQF04+4!sDFNyyOaKrJy}k(7+Z`|qlJ4R4I|!YCM6L`%>0tE@<nBf@tuDpF9=#)2>SQqs^CRmtvC_+wV0%'
    'N4xw3Uxn!-'
    '(;JN%o>3;fR#iUG+ugmY}c?i%lv{K1VB{l>vXw<Hzn!lvT6bAut`a5cV0Y9e*2A=W?C=Hb^Y6KOlScHyNFTO<l9x_P&A6?@lun2I'
    '8bQN0A*9t)H1sFYT{^A$#aGQ5d>quS(F7ydKp@g<>c^1S7%mbC=|i7OO44TOb-'
    '%!u+~TDX~v6a_D{LSC=vc_Qz2H&mZ+~rya^M6Q6n9l!-'
    '^@lIM`r5dgS`CP>yAbMLx^ZrFUA`Kvg5nRa(JxVUcUtnV+(Zd{6Q<T9raeSo9KVzJbSSfdkL*rLrMgql@djrUR5#>l}B;ccJ_3w>'
    'Qu)a077Kb68_!>|nS4bnmv8r_Y`qPrrYDa&nrGmioof=}*V6r!S9Ak6yfzj$y_Ht8?&q4}GYHz-oPl{{kNC_lmS|!@*ZX+{#P-'
    'b<mCYb#<PI_McPxD_A$8=cLt<@V@Lu{KYz73=M>Xp$lO+_{@dyg@xeywsl4a7R<<>$d@#cyvWju2PWVcPdHc#3*rfbu#;zi_~VIe'
    'tz6+cvgwn9*d$`>s2%P)Be4jhg9C5UEu+`&d7Xoyod4&|gBRVqK6jnbFxUy(tDc4Y&}APzBS1$UUAf+oMY8t4!-tP1F|JxeJL-'
    '8xBZ{6-DRKT1oJ;wjG+nQ&SifDzr!HM(9ekb~qOpjwmOf<D13)2g#r3b`|IkZKz0tc#{~P|U#-'
    '~kAjMbF%9klE`cBME6wPX$Ri?qP4YN(w&Y-'
    'xoDCTvG)JS=ql8{Hw6myIo10oc}bG;D1=R2s}i5bCD5uO8YF#PhTlC|RKo5!G_InD|doRzN!QKgb|~m+mpc2u3QZK1#lVu|Bk$E6'
    'Vz$K}{Y$G~SkJ4#eM@9CsFInu8wAg<-_;*d-'
    'ruuAfx5WZYup^2`(wZR@ZhCml>914FZdH61@x0?GIGDUTb;P?Vr)y7~L2TxYDbC^F$~ums|@bl%+fR_-'
    'O)@0%PbX_arT)s^Tmy#=yV%=F)^LIN)J0);|c!haimmXQ58B#7;UjqQu^+0g_0S`I<7%fLV7z}n%xlY@YrA}PXSeZl2u)dc82-'
    'O%oU8a@)BA8H_;ic^3Tql4pM#@+J|mU%)rihel@XTkhg$d%n?7X9tBkRa`P_aj>#%);E~_Z`7tDB&-'
    '#rE|8}Ad$L0+<864$E4O!!x_FP%jIE{C03~Dc4gRN4MWwpTiC1vcWaC$_@H-AXJC`1nQLT#`3Yp_BT0gB-F$yz-'
    'X^?3^Yj|t9q_W(!5R3i&Z00tZp4WL!Wih66uk)Ccnk}8pr8rQ+P-'
    'LbV10bdASm=}t#afl)qo6F{V?gMzzhl*^wodU1u(ii2A&g#b;y)Sea(EcrFX!^US!l)S}k*EszrP7kV0Jy&8SpHWbD$V?Xmt=yUH'
    '&|$Y1BzfT_|VD>t=z#SY}6I_fR=R5jZX_N5`A@*6@6QO|t9by0~MK5-'
    'LkvA1tnfT6ZwHil=!CDCDun!LHnt{dHeYhoKy6!nf(c6DBxi2a;00pP<imHpwgslC8&%7O@aLnV22+w-B)aTM$-'
    '5FGAZ0}1F}FB}DHt%eSvKmknUb+ijC!0~~pkvuM@P?CLjUVYiQ!&RmWEn@Dt-'
    'rOd#L@Xph*W-e<yocCeS7Xd@26eVpM7>EZ*<4+!WWBSfs(bd25|n3LLuy-X801bupEghX$Ohz-NL&oNj#Wn2EGh#-'
    'F#>T$3F31p?ywf&nk!<{CP&Osqq{swS2Dy*S_i>35%mBIw`M`Y(p5v49gOX=w~n+d;erX{wW+qk6j3yq$V)HjE4{IMc(}B?tDR}w'
    'yi{UPE^_U(&0rgBwe{XP6Kk~FLkdM4IJyu38kIf^ruD>C%#6d0mQRB<&aTAcfPZ$lhpr#f#SiLGWberilG=8|rQmbQtLRwCF_cME'
    'CM?Bf&LAn|5p8!P#5hfxY?+5z&qu0<D4W^#EKxU&=kNjlt)C?=*OP?FjtrM|Yf`Yh?TW55j5)PduFelG;X#D^ny{b-'
    'PXcyrKdFIcbMf6+G*dtgD~uL%4|Ru<+%{+rJq4WqzBEHWGvoHXK*}n=B*#M!TZm<%k$N3&t~=f-'
    'bPkG!>Y$XEYqT7pTuXnL2BpOiuI|l<_G8e4ZJ{nANA;6&boh<vL|Yw^Hdr1O^SA3TN)-'
    'b|!@CSdR%NR+uT12$XUh4rzrYXzSc8ScN(IBUl_S#oY~F__4Ul{!7Z^2-'
    'dqSI|j}q0YMl!UUX=YW{g0ny~1+uH^84HMb2&+4Uh0yP>R=cvUbfDK<?=vJeitXK%1Gct|a(Wm^&bcMZI-'
    '#d@m+;d<quT1RYs?t58#B2lpe7yfHJg6PdR;OMojA<(g26Kq*W6S%a+msY@VgenuxQjG9g<154sGQ8&_SYG4qZg!o!F6oEh9HEiz'
    'Rz@Ft@lAMi=NVxppPGnc_m$<F9ZR%GI<i07I;2S7XP0lP|(+QW7SM6iyC?+{l;n#{i;O_sgPBw+uF>gc=tpB7mQKuf)|eZ{DM|P{'
    'P6clb??~(eIx9fa;hNmUbZ(PiT>H3=p;^V?r#T7xP?um22LS6m>i^WwJ^@|5hVA_%_EUr@Zsp43ONn^tc%!yQYvn3Gp6`=mk@8-'
    '3A2<>~FOx(#3-'
    'H={yAtMY4gl*v!z0CVbq=rFUtUEHReJYh|$gVR#598Xjf%pW7IfEv)~kpttg~S@uZTJipW@BrL?WziBI`fj5?;5aEW;R%}?=`&CX'
    'f#vYbPt&5wfF@wfZSPakesYT0u2O}fqc+>UWEsXJ>OA>plZ9GGGlQ<Vb(h>aeHMLRQpuxvf53oP-'
    't<x0r4^G8Hg;UQT;99=Tc(HDM`#d`!fPjGZW`pqanbS47(coW2#P&fNYq>~IuuRGlR9bLJV{H!B)?%^kwJ~PfJW*V5+|p)~?Olwa'
    'cQ=Cmb4`vLI^bPan|Nk-eIj>(kR0Ntp2H4d6eaB$`8LzxeEeg^p|tRj#%U=pAzl!s<LFuuxQ{#Wxa6Y59KF?eR^_UrMor4Ou%bMs'
    'aXixG!X5WeNAWG6VPGT#AY`@IY2`Atn!C7++SE21d<L9`=*5t>2a_$+^^o#@^Mqj^pmq(%{xu@5M-'
    'E|%MtxB<bi9?HV;3Pl3sFaWhut7z8eOQd>9oOBf9GQo92J)$wYmAn*ROeV^^mu1o=Y<KJf*wLd-tmm6)|<B0|TGQcK-'
    '$EPIp5a&5{KM25A_aK;%!M5d7VbU=MDe7aH5C@M}UKsR!u=Xw#o}j!|Kl41Q)&V`FVCJs(Xy?YMOQ;M-'
    'rGJ^ya%g!g#){OIS`@n{wek+j&aA^IfTBPK_pLVkGR!N}W;1C1Q+ciQx$B#2$d?3u!jius7uu$b-8!+_>|dF^g@v7Sd~h-'
    'W_pcv+r)$@j)Cnyl;a!LiCF%#3X1GN+SR3*p2^BmlqB<_HhNp(33TPvsUz056PR?Y|Hs(6%}YNYl_p?>(-'
    'nSnf74j;`XpedJHKqDvsgq)zTQAG?jFsBaIR42Zp*X2q<WXH_h!KI(MQP7}@d>NTRX%Y4RMF+29G(h3%Fwk&ISFfPk-'
    '1<#8aAELcwLsSb7VWu`nReQ=-'
    'o~pt;U8gf(rqLQxRWP4amGuo<DRSviaia|ZDQMIy8RlL`GxBZt!cg|n!1$iIoNEB*8MJxUX;FJKj)ed1(W~PrSrtUB6AwO*m>fQd'
    'MV<d**kBllc7cJZA6oi(7JTB1w#plQ5r)A>ySRps^+Of1{?(5sFQ;M$%(T8e`sr9%E9!N#leJcPFQ5I}za32ximGbU0m#r(LA!5H'
    'fBE_8kJDE#m1Snwhaa)Zw*B?!^ylfT*C(gPs;SyJTLTS0o}L~by^tdd!e7~Z3Bjz6Ur(PNeXrr0(<cl%U!0u0{_)xI_6~#v<I(Ah'
    '<I`7Dw&T!a-'
    '!E>LvSQ@uYI@^7IwOM?!5N##L%g0n4nRhRUjOe{M^=FAt~1nQT~C4HFY?O`6QGXsi)KK^FED;RV8mB%N%MivJsgeGhP;%@cg52TD'
    '`HrpXQ~C6vL0}J=mU4u$PHhlOI!oZ7OGxQ`SBT(v-'
    '1ZS&Ubd>$dwUUuBVHPB0$x|EgdTM2ZoJ*oYC5o>VM+LiBsse6UG+uN`w}(RfygkaqTaOriMJ7@_==@yeRvz;Ns~A{P%4GZ^J<sgM'
    'f=o!44yV4&%WXqjS>3!V1$5`0v~1hfqVj#@>!zp5d@~z^wyQfpkCce_IA;<2Sl!r8#)x)&P!;K^#AF+FPSH?j5$VDHqAZhacDgTU'
    't!h#lX)!KN_DFKHc^l5DR*|QtwlOcZ-'
    'O38%PsADFW1RzZ#5|1vX3Dx=wQuhOYs{wupT$Jaizvv9JUjRbuxuOutfJ!R47}*D&ZQJS3*`^roX@9jHNImHLpL#fT0k3dlqCUuZ'
    '$L$34A~NFA7HDK!J?Ks0cwnjl{8=^$`00FAMAsV<xm9q@`BgL`BQTaY!g+E0~HBaERBV@P<uJw7?e5zjZPWj>=ozgHCcmC<VLnD}'
    'rjB=!2*nOM5|0>jbKtelC;F?&O=J-G<UV|@*s*$Z-^hT(65wCJTC5wycW(#~V$UgE?-AmgPK*<xahU}e6ep-An+$fZJJYPxn1*&W'
    'x#K{7n+hoV=*uy|XlZT4mC9j^uv@m%vAEIO7HpGSS*oR}@k?sd_1+B!=$+S+r628ZC0-'
    'B6OK1MzL7zKz8GMh=YY(4Z@jz{PnwY+Zb32_A;Cau6=JXMFHK&3mx}%-'
    'tVZp>4D1Tk=Z3b6?>z_t3iE)3tPwf$rlv%?pgKMf)I1SpVfzHE6@)1!zHrfqbzCgTX}L3>Ab`+<X8wkyq8?93MMKgS@G5p=hnghN'
    '(@JfNO0mQl`yK<rrG0u`J8x(LSxta<NPW6I*A?MH@z>0d3Zy98PO8H61}f12&cLE5e$3_25fb&D(yjiB}pn&+DnUY+l>wg^Y|;BX'
    '&lhF2&^;;&&bNr_R>$t3zmSUA(9<w1a)U%L(g@d>|dy5BTp}mYK-'
    '~wntf@?jR3QJH8NosgtisRM??=H3n>PO?7)A!>53n8`1*Tzf4;oYmbx=f(Ynonp?q-'
    '!E_BnrPls1BQYzT>h$=GHUg3n>APW<v$l0NF;Ta!Heiye<yjj6LN$(GEje6Uy9NGgwG(`Wwf5+QPbwzdQ@nIdij5A<32W<tcY7##'
    'fgbEf)mxzX(cHOGkr<X%Fxn1Fts{U>SxXUnj;M9`z(c(??}CY&+L6y7zYLsdD$)sHEFaCX;wedh(ZWE<Z$gQPbQFzJR1=s^OGuPC'
    'YG^Xz2BITHyr|!3+;E)}_q=~RIukNkEA(w53NLQ=*yN#5qmC!CZ~;zOE#~ymJQ!n5zl(zm%9PxyYjq++mlzdtPp*7p%spin<n5Gi'
    '5oB1SuqshfrS-'
    '<doS!*OG@08~<kl6e6EVLS%^iEg*<yF@b0T&)oCnD^G2JVu><j652A_2!Z@*S>Sn*|6ea8!;7UJNuZuB9jAPHNd{UnJyJt(@;Vms'
    ';V)5aB0y4Sqpnw5<`g(s}j82;Cj=*D4`#>xuq%hBI4lAOn&@qHWfe;gn<?lJ#Ie5Zpjrhj{16<0E*{9sz5srVu}UWcC;H_H=Dm_N'
    'i*498>F!l}27JUCus=a*O0IoD(7msis}YGd!W%&#H-'
    '_Sv8DhiHnH!$|Jn2%jfJQJr1<`C@6>!oe|T^;eB77InXUSa3bZz6>6TlU!F#4}yw@VQ`LZHve;{r%*p(^(~n`{n^pW?XMdRLf>^b'
    'U8~qe2U>J$GD_`N7&3@m+B8kA(1jSDh)#<5gC`usroXQ8%S&|XKwMK4CIAn5BKywBsHI4g#RhsHb4t@aMKjV?+claxV^AZ;baj%R'
    '7dC@)xylOGpkJi3Hy5z!|F8jzbl`-'
    '|MSW9Knu3~!5A9$bF&J9%?g|4lVYDFjHlAxi9vK8_w@;cI#VF=@LojUewpOZ>RGXmRMRnh<nRnvyMAY;zIIp$!3i0g|bVdCz?745'
    '!zbM#`7w~3yhj2fB*qz}W0{(a~z8Kyy<j*jOnls!x=+DrJ`ZL@&>`(KG?il!|bq>3Q{&A)thp=bxpU4+K{Lfz)W2ZU%%zbd3|4)M'
    'J;FLZ#e9nECoBJ>~e`c5)j^>iF3vc5gw5e$9nPe>p6{3>E&1*`m8>;U6__!xg0{Ye$8yn0CN+~8qx)jkTz4!&(!bH{fV|>_X8&-'
    '=IhSHZQV!MtkPlw`&1mW;O%kexKb4!_+`$WfQRGGu)WyT@1)A>C4AETsBF%!bNG`{mjChaAl!V!HFI9`ZYAijBm8kHEb-CgzQEeq'
    '1Tb$s=?r^xbDG-6j{YUV9U=Kls7<BwNQvWw*@zg@Jw+4Xfc&yiPFJEs^5?f)nvQaeTE1qM0J-'
    '@0Epa?#YiuTGJ3b%n_sk7|l1b2_^!@$9=+6c!yc=_aj-1-zTtHpF(-'
    '6CpN=@}2WdYiQN)tFp@fz*A~evc0&$hj(Hd?K?#NK1!ra5*UQ8xwkReN%XumpXW6Rm}I5DfBxqhg~X18LYlbc6kbZ75W*Vpq}|lK'
    '_VfO_?CS@ymcW@P)(q<vCyvJOvThvSSxM&K9Dl3NX5ng?@Ew^X-'
    '|;11=hq08jySCj2Ak2?t$<f9@vBZmTl5d+*Sd}!Mo!6m|LbfWaTyMUr~a3H<(vAPh55mC38n^@?y}C2HThJ`>h~Oa6A;Q?a36YR3'
    '|-'
    'IG!1L2}J4T7A+m4PJVr*#Fio#`5r^TWsx)KsU=XSXiP>BkJ&VYos7@mdT3F0IvkmV>0C){}Bx?ao>+2y~)ZH{6wOaw19whQEBbll'
    '#JZ)3xLT9jA=1vT3YTbj>eM5E`L?0CuJ!u*L=9V16h`j;)RceeFuSx}$U8I-'
    'sOi{z3n85v&VRp5E;m3ZiN;?P(JOUf{dKJgs0(9(Q&G6y>YQZ?O=j#yXI*8nD52e+AM<<sA>MF&A8edWhy6~ctY7g?=nvaan>W%5'
    'mp654n9dUiFPmGwGC<sLqK^A27ywI)P@e<z-'
    'g{&LoRGVwC<QaBkK55vS8M8rdB1FrCy1Ssom&K^lDI=sq^m^294I*kV{bc!?rakBlX%+Gd>J*oE4Q=vEz+sg3HeYUN_fmfmPM7<3'
    'KTKC}Gx@tHMruHF>-'
    'gp@0%ru1<n<<zL^^6^4(onl%P7+N3#^F79&0{GBdrrc6oz2mX(R;Pxbk0m7(}B54ZmoWTw8BZWJ05$BOQ=ejeAols_4RUnOj~6d^'
    '}V%^D8$@1vR;86jojY8fQpfN+oWSQysr6lsAb{OtgYwSChSt#XSSm(aYNkJr)8nM0D&1pgJPASg(9u;L~v#zwyUdEac<?hToXU$M'
    'F*FYcBpO_(W85eWHWya+_tg3;Q_E+?7?Ril*h&x{Sk-Sn4)kbt!}Im3Da*#RSBUeHF1hJyXHVSs7BJkvOX?G)}4JGd&$$36W5rY8'
    '?%q-W-|6-PY2<X`WUU((hWk&;)XKarpvKLXFbQXsF#qGvC$qxDSM7yu}a5=s}laaJ?X-'
    '5Hj#!i_**&$1feXgQy0>)`{<?nM=z~`ZUf3=+q3C1D=ybp9f~OBnE8^o1^%2&JgKyD{!&fC5W)`4<4~hi)z6N|Bd`KL72<^*jEe-'
    'LGd!foo~|+=E%eSJ3opFLZF?POL3xCC+p|EcaRjn9{w@?o>UEaR|9w*v)v%FJJ<}f*6+B(8u2RLG1=w8YP;UyWYBQ}-'
    '#jjP2rCkC`QwtG)3tzOJd7wAst-+^v3pee{Y^l4rWv&d--1P*Hh8l7Eh{bS_Q6A`x9~L?csBEJH*0t=$Yus1E(x+jDX{Bzk@0w%-'
    ')cmn(jyh@{pia>WTyZhGQIZKtD&vB94B!Vtk42$9ewZlrm`9H39Cb0`vjW}?gAo(YNKs5R<8q<-'
    'I)(AH_o&$Ru@Y7}?o{fOi?eH<7Cz!t#1{z$SwzHAHtAT#nF=_k(=VB*An`E9e?}BznJ9dx;KQ-3wGCG-'
    '?$)X=wZ}2<k2>TogiesM)Xo2?1rA%#ieSXdVwptaipyw?>f8;YFz*_Hd57rB94R>(fw^uYm>f1)g;>68(BuZPiMB?3$rLupvyZ)L'
    'A=mHtCB|O(2cO$FKA;!i`mU!&zD})m=`5|Urt0Q7?b~khx9YL~;^ou+GJm5|#Tnes$Cq-%(za-kn8@f*8`<>#(yes<G!z`e!{jQz'
    '$jPh<U#zPf*#ACn1T6#c?HmIgX8=2>-'
    '54*g);a~<isV6SCG}2kQ2LC*bLOR?ZLvnFxVGU!g!Jt%zdru)+39gKpyf7{lkXgJKm{m@3kzcxVh{Um9c}SzcjsH-'
    'E7Gfy{l!8b+ZeNjy4-'
    'GFl22@2lGvqDpu5|qxfd6*P=sH5m`F!rG`slPJ>9Kc^XZ#=lpsEfebGOI)_Bv$uW<^|%wlbklKH%rQN*cguFOlYU&isrKH?qBuVf'
    '=S<bR_~QqEvZu-xx~1@b-|pa;v<nvCgZo0x9gCh?0|xd-@n?ELEak-MZKW~|rMwOJRo;#?tWF)q;hSp40K(q)SGsl<2R1X>dB{GI'
    '80s#BNfrjs_BserW7J|hob=D%+UqXOO&X)hYz<Bb^gE_m+~KiPETw(sjcb4Ax@o1yg`9Dd|eWcP$PI_rkyS!pY!oR{viGPQOw7U3'
    '2Z%}<1?BF@*E#i($<5$m}STeWJ0c<)-$?l`YIJwL-'
    '{GVF)0$qtEG++*yN8}!$n$0N!eB1buLI7*UaAC88TX5R0A3V9yed7Pp&<2ef;^?`2_pBP7J6cGsrb7jXq6&~!?r+PY7kJ5ZSow85'
    '$p^q2PmzFc<sXb@cWM3}Rlw^a_z+&tP1%#uDe~^G>whi5HOnf9dM(RvIo#|~E4RB1<IGL9;7wUv$*A<$=Rb(^I(d)EW=0P`-'
    'UIRPUc(1GujiB}HjO4EHuL%kjDn}&5)m3<73{x&wfC84w55f!E1ddki`Xj2{AKl6bh&Vh-'
    '<{V*ooM2jB(C!_*FTDuiJ7Lr<@w?5uIO=pncWsx<MBtWd<oR2<;7o|^hLLPLJf2QVZ+0^~>Gz}CwqBU_nGyhBDYhX@DL|h2jVDoK'
    'Wl1EdA?1qT80h%8rf(`QMAwO}iKlAd9AEn*41<ZatsaG4XN&^nB|L0OT$M=RNWNSu2Ola>;7YMl<S*Bt1p1NDl$K+9on2!%0G0Jb'
    'HB|99b+(m2wIWhW=q7&3385EpRZX@JU*5J&m9mS%WQ%FxOWv)g)KHyNJ!l*ATFC&u(zHyyL8na;y@St%B?4x|nDXXN)#2!vpx8X('
    'Lw6hi!})FFuB&LJ#&3#Tue4PFo46rvU%x9+Ai(Et0n@=M><DGW2oICz6gSWJWM>mJ*i|-'
    '8>nnX3vJQRR7JlLZeH&;vFHe(CM^FC#nGcDVr>}*yeJ!Mm!(wQ}11Mfz8PHiC?ZwNdB<yf3^3sbM<t7&yCD+9H=ar4H(!Ydby@Ec'
    'k%H<qj10~GoOxCYqiQZ<(yBx1uAiN+;^KqCtMP7e#DLOF?nd?s*uh9zta_$vg%Rz7$T}Ax9i9R?~qRg@7rt8oryRkx;jjQJvMQkV'
    'Cdy(z^N%p?v`c9;Jha4E&h_lIlfd{SQCbhU@bb!5#>)e?0-'
    'oD4e8L~`#tTt>A$AZFGD>TlNUAhOctv{1FHJZ6B(9T#pG?6^gQw7KokG*l<A>o;?dA91)xK6q;?HThOE#b1cf}$eoM3^mcURsJNa'
    'jDRJlP;&~OleZ2t}Snerb|AdbHDFMv``rCnZ6+pMQ$tB3D{6CW93$QP9V<ai3G`+Wy+E(di&N1U<(A16>syZEKqLVSJ#2e?NWS9B'
    'l4%tiZZWt9P)e(<fcz)b5xk3MAOGjt&&T@`=&&JI|T-'
    'Z7igb(GMyy04;z(=XX`&WeHHL&8(71+C6j7I2CmA8g?XvorFC)*?^F180kkqHiwG&R>H$sEV6fko>nq&+H0KmqHBLqGoJzogEJK9'
    'S@!lgQim@s#)pE~CSKq9zcVKn{7Mw31o|i0Abv}c)r%Vv3f!ObNqc#6|SXYfah6N3tP<7j1V-'
    'XD709(Q3N^zij;Uv|Y+GtcFb5Lec#m?8(vMY5r{6>$i&$Jl)I(;KvUYMj11!7r2&jeCw^zluI7^qK<0o<++?M(XgwF-'
    'KmbZ=|xgQmg<kYfh&-E?g^UHWx;LoRBF$A0_m+h2awK3Ko~c3vozh_-_Umh~cAl*Goe{1;XGGmd1WEHy|`RN%!`Z18WtA<t}~p&c'
    'G4qbBVhjN-V!-BF4^bX-~H*Q5?aZ#h)*z>X}|>aA&#AfFdF9i1AUX7sn3WUNXZ$@-'
    'gK0z0nEFYrB~`{~h0Q+8B=Hx()t;TdG2KmgLcyjmNB1oEeukr6wGaR9sq2!a=dP_jvRkuJ{*idT@-'
    'C3J!Y5ER4#Hv&`G!q~|hr>Hk7PoN$=jn8`XkY4k;q$m`a<lbg_=#ymyAl(XM#a?G>%$WRPnXNTihBg!}11q0nCPQs>kuIw&o!|8N'
    'w9c)e=mp9D%EHMB2o2#4lrL^n{y})#GV!2^U8PtnF~OGg!Q{<G_T~-|D)to#YztRGlD=o?YZ|q%jHEQ3E#csy-@=-'
    '&c(YZd^b6Y0p3?DnBqK`ZdQ`marzfve41W`wUqyFNG5uBi3lq-'
    '&^C6Otr>6kbwDsd>jE0er7$U!fjdAgLV>*gqBpt<9Ds#m1qo2Riy<<QI4#mL1I)>dnd?sHYLUe>1S%JGZKcvJd03I88rqh&+NzIj'
    'uK246ux`;32x=QC3T_)EXVu<qP5@il+;_&P()*<2XRw~{D|D3k;MhSyl<BKnbx~N>i0l@TTvi!@@7h03_etLm8Q<vz5TCtB~Cc|_'
    'X>LM5RAESY(iGuU#-VO9ApRTU}Lm*=&j6=M-FzqaTGu0w^;|BSaJJ>c$6S0(N`xdD-'
    '5boZL%%@5dYnIih_K*ibt;oe@vB2QHVv?U*h2HcE5MEW5*9O4QE<4WH6_<Tx3zZdsDi{p~OrRv`O#9$a;c%w|ev173YrsAD>Ns?5'
    'DTVj$#pXs@`pA6s5x?R1ZhMNyDbY|^E7^}NW#UelO!x|Kn+<Q@w|Fk*7;spv9TIM56m%wt#5$kxAOxf3U3Wek3S++dAq-'
    '$ze?bHT9iu?7MhR|9f@V>bee$8(1qM8zLrHQ$>FtUQ{!_ykkgh;V^k6_?90SKEaOCB5uGi5R1LOxfg=gi8xZ^E8<WcAGm^T~yXl4'
    '{+ka<hT2_|-ll)>5t4NBhugGYWZ$Z{2uMO8_awcP^p)NW>GXXoOEH-TpwEsnWe!d+M&%AO2DVw$U)Ztooi95GP(vdeHijM`fVfSC'
    'Heh;g@N(OobUwb{<<c0wPuam1`f<16JoNnTq$*PhgK+El+}Ef0;k6=6Yqs1ejQHh)FyiP?|kO2i#8#o=yn$K2_FHy>t2XNYRXuE8'
    '$UJbEWo^a1B;oGJ$^6tZB5JroF8OV0ILdFHC|sK?J+@#=h8Ja<jAm2rwR=ZIm0ZFXYq-'
    'm}|IUVMee;itGomG3mkSa;;a3h=jxoZd7-op??#?;<WRxEE39ORV0LK9-'
    'nTDZ$SJZ_j&4AHVvzM|IE%4fvu)V?I>$5a(OgaMZf4WL(Uo8w)gpj8to|>7KnZo)?j%yl?Y5$LFM!EztW@A+%b_1J?LR#s&DBijm'
    '<uGw!2P**PGyj%943Ti-pDvFkTE>V0f%<Hpd$`*pNiuCs=C$|9T7eqoh;pP!*??DsGJ>bcfxGT@LOXJ~t@p*6=5?s@@-'
    'q!nFr>>x4fN4v!((lCRF6C`p`(+zgfop2;^4JDV01~&49s1Y3(Z=Q}i;cRLXz&#^RMB*oL)Ws}a8<gSU1l4Awa_F_|QpGwC1$>lw'
    'y6}Zzs?yV%LEJThy&5P7k!QszVO@Y84;XK!zne$vtX$<pH9pd#mEm~lcWIhjqBE(fQl6#n=W2k6th<5>AaF|F>$G+)?cE*~D0f*W'
    'UVo1DrtPK`uvKp|<casN!KyL?Bd5qCVXvQmF*um@=30g)iRZ1x>q6;%W61?QPGpy)jEy-'
    'N1G+pVNkuwC|3pf^U3V_Zv;qp1|B>03aGkBsyw|XP4qv6qg^ScJfG!2OIB3e2*P*t3q&E65$-'
    '7f=OOb8a&?=HTZn{q2WSwaCB%GAsJz@d@ySoUcQ2v@SW_jcV*o&6O{2ELK!=4{lle!c5m=qr4t$<*KsHH;_sO>k+@sl{TC+WEs>s'
    'E?jyIz$m)itRe-Ea*&0<!}ugvL}^&#Q+SMb);>am)!y4>|eeVXsNd<_53vH`iEL+mBuho0mK|;}oz4X1`vbBNQ>0*YF5Jrm|#R4B'
    'p!pFYskl<rf=AiGM^<!cBH^W=gesOlhrIb~s3qUkdV^BNKro`L!u^gSukba)l0_Yj$MQA=wf{h!{2U<+G<h{qizN>*O7Z2;jfpou'
    '0gW{POwH(_@ai!^$LO;K{OX#0;p(TqfTiAAhGu3WNDEtx&)Q)8mTJr(=~y3d1U!=jH_g%R#Ecj5PSHLsB#4i4&=Lca_hs;30!~&}'
    'lJs)tQJ+5>evc%|GLVw418vaCQ%47c@v38uy@}j1qfB*Z2H7^2~b+fAGz*_ZsJxv05QdW2Aj=&Za?LShhw?SIi^E;7lxIg#40bs;'
    'skpt}TwwC_59BYlcY$%YYdVC%|Dp?8pj{+@w0s9BRDBF$Sq?Fh^Nw6AbJaYf8=r`cj`XpQ1psJ1MedV%A;7shPPr{uQ>Kc2|K_*P'
    'f`$%wZPw+(Oc=MSg~c5+W{$GpLn^jGml|Nzh8e^-3_$0!IuU9GHv3%l-}g*Xv&}HM*Ao-'
    '1#nYfImIK1m?yXMR>}ijC*QhYFK}HXES^+Bubq0&DdMsM1$2uax=C%B83^J#n_k_bai+PQL+`T(fN<<sXpUuP;H&-'
    'x<LdMLd163zE6C75U|o(J)j$&(dBWzIF6!fNSz`2aowo1tj-lu3HttCem}dJbhocF@t2$!8(W+?%Mb~#0h<>rm(i;#KUc9IIIVM+'
    'g%P#!eT>vjy^K4!E?o}hg7@KY7ko+A(lRp&QO2^cp^DIz^gApFh3W)`pWN+C=$dX!7(iRZLOwSbsfX`-'
    ')Mwl+#XxCtM1f%#ZZ2@?O&(bQVf#<XV#H{#aETKP(+GH_PSEImv4n>R?7|fZ+0sH;=#f>$dJq|JJF^%bueKd$j;CSI=_8(DafrGk'
    'f;bGN&5`rwTpISeyNR8J?Dq}xNqh|@h=WO23wiuOJc$O|#0W7fxSOwUR_x!_6TWWUExmiOJoMXy-#WPO+AUHYGt)MfE8Tl(G(Qg-'
    '9v+YUC&wPUiVUmT)IW3o4An#JnNJAK=)<+>M7+ohsGLpbthC#)@WzO-(YJoQu6Xxj9!L~LjK{XKcq1z#(9WC)#;qGWI^G-'
    'D_~1sy79xASG<@e&zfoM<-2T7Vefl$yzC`#9>o4ely`T#H$HMtE<Nmwi{n#!2G&yEl_0izT!Qe}Lw3SPEAM!iPT;N(i_-'
    '0qxj7&~3{z6q><trc}5*(YGr=*GIbDtz9Ohw>F|9Z3L=qna9uK8@ap$7O??MZNKo>i3na;2Dd>Hr4USJZ&TUu$%-'
    'B;!%iz_?izn1ewS^!()MPnd%Ba3}obJ7&1(?0ZV)>bZXGh#0*49lhIF2QQ#6Ib5JCN2#)OexJhakmtug{K087HfxL$Txli~6Y&rf'
    'QuO?yLu_44UY7Qf3sgq;^hIs9VIdf<0gGyV(MwV|y%(;zv={<A&Y%r|mL%baLt^lHp<13TVRZH;C2Psyg!A%6^9-1*y-'
    's=pXe5%=M<h`yK~&t9$O+F%mN&Syn-#l}U<jheXg8U#d2v;n6e(d!6vgB7yu&z)7#~i|uosz^4o&Ow<2tsF6-j!B9Y-'
    '09T;yF5rAfBJVsGgvVjUeNG0Y&;izq`idsE~UGpA6mA5H-'
    '6w{Vr6No4QWRcdj62svgpHBO9`>lpzcO%H?O$CWAX8fBEXY|=(%+m68!P)!u-x-'
    'r(2>f`I=$;X@pmt5}_X=rEqE5Hr61(b|$+N)y^VXI9rhR!bad+3LDT*kq&m30iTu)n?=Xr)<>!KRyGqc~bD)s2C7B=XvZP+P~|;U'
    'u}C>oA;>FtL?rH72014@CqMUr_HFKD)u}97CuUwCrP8q9=_pua(`Y@^!$$^Sc#DNPUIo^=Q`nn0yr80m*^KEPBde3Q>v+#}aM_w>'
    'C&Nm5a%=Jy*7#e<WkJ#AX(N5r5j!&?Lp;0G5x*hLP=!2pV-XZ*y$OyO)O|W@e4lmBa#jv%YO&evgtcvxs4b7upRuM))m|E`cmp5>'
    'dG32Quk}vM2atY{q`rOfCZMUd-3AWH4ULIw~-'
    'BJrNQ0<O;YN^dMrK4nC|T@vhcc>`B0NqL|RRvvR{jb|*+#%><wqdCr@AHnx98>WR+Bav)*N@VJd*^j88F7kcdd_FDJ?89KC&#<W6'
    'VY<L;zmXN^oLR+8ji@+l0X|AVm;EmFAv4T)u#`8Tj*vB^@8}@h87J2fz+i-^thS<lz?LQz|867s?zTFE6rrhx3k-'
    '^;6)t2p=trYg{4ivXrgN?Mij$$`d6Z;u@HLoG3P5T54fTrP7g_f}k0B(O>>%6Mblg!THoH^GJ%qfZsuLy?)*p9RUTTz~xn3fk$9S'
    'MnACEHWf><^nfRW0!3sNHa7Eka{ZMQb?2$rcMvGZKu)wcEhaMZ4>1yO#LGTsudR8-$+8_P476-'
    'oXOG4G|oK2@Y%@#tk#=H4O0G6<f7=X*rbk$e9OGD{&xQl!4MD*TkvO#w7xy+oFMvuAVcUPm^OOcKEEkzRrnPtpV}RH?vH;?HRY(#'
    '5Ms&Tp3_!Xc&J-8aE{9JiA1B(v3FY=%LRp#o+-'
    '2oi8aw0(<Vh%Sh@DWg46`hZtD)r%K6ws}s{&H**G(6JoYP2Qvq7lAnvd{y6%Jcuyg-'
    '<e<4&?B4B)zd()~KVeSxH!kSMACJ<Od>;v}FQ3!?hf~@FAN^2j=~<R9JE1LKS7vXP1VQ>DdU<KMJVOj2rtFTP?=OLU)5_-'
    '3UKu|#3pn*0h8pQZ&jA)sUTolsG#b20Oo>dnUJCIZRSOdMRa&|v9PGziUXe{mPJXd(0zVqBdRmNyEJ>66z%A4fAPLsj(qReM<4ha'
    'v)bY6dm=^P=Fr^n5>xLwzMC*+O-'
    '+oKz_%Vj)c_2epF(=q}p~n1cQ9q%Mpk0}0(kq`8?RdS7>EAN$mvPw~Zy!d_J%Y6Oo(C3>Z5#~KS(mZ-tJh@CO7xVmXvZUcfyJj}e'
    'Gg3#05Tn(>}+lrO^O^5?h1cV(w_)pKBNtXK~bS3d^b^T+qRRXSc9>HSqW|Da2wDjwHO~makkP9BNpq00za~2X^3_n(wyBxpYKIdL'
    'cwHQ1R153js{MRDpbVveecSM&=6S#PiolnB$WQh{|tTQRuv*L&^B_suu&13B5^N?<hd8q^=53kfsM{!yE)$exu-hHN6`THXO&QoU'
    'H{2vR>SlTtmf^S&uh4tB6T7`4Nj;7v`MP%z<xAlP|i8AB5iY4e4kxDJIt$hqE58i50AprA|u%jKKAzqXY0Y48t3vYPUV6{{mAn)^'
    '&$;ybEcQwsYB;QDG1`q98>%kH^LuA=vi!*IyMYhumg`&a~3OHzPx~!BXTW3-IXXU$X6w!wTnRQy{HJXS;**$61~Xei-EOxjz?zos'
    '(aDM@UR9wcKk*ZvPg$N|8PsOP(R$>dbJv&xVA)c<syuPleZP#Oc|HNE4*(lYHO-'
    '@Y^r=F=I#ABp3qcj5LP2L_yWb_4RADRZmoo|vRW%-^UJKY0vx-'
    'n!WU`F`lvWQOAIxXwbyCgqj|PkmN&$9)K^UlqrK)A9157;3ES$5*WI=j+FzZHi;nPvwMAkr;~!@3B|=@Bv;gT^kr<=A^!+YnvZCO'
    'Kn^?KnZ6u$}`2%3}iq<n`VnShge-u=}D7(wN$e2#XffQM)V>7jG>2*2J;tLeH`y%{rDucwh7r!}<u;vuGwb%g_{p~8P>7-'
    'H+T)iPih3rRPqHRG_D93ywHzAvqa&qKQI9owE7)bOP@YOtCvZ#{6B&9TQ+MXH6ldW36Na)JK<Z%63hnLV<vz(Q}UfjSA3nyW{qve'
    'vmba;My-uVr_HY&ejSHR7&7!48}YM<RGT7g_%%jN}@8i=I`l1aUf=s`y@?Pn3wm}<>Lyd+qVUUNOdR!l-'
    'qXs9o<>NV^vEJ1Ul_#_(|bmN~X?qm#1SlwT}Zeuzrc^tnP%X{Z1A@T0LL$P8ZV1pJug=&c#>npkTbQ9b=m6N(qNN@t_wiXex-be0'
    '0qrPKDP1(-cGTCX9$}Dn1BDyp00PLzmi`~_`DAT;|jkv0p+)a%ZN|~eTw0%`-O~Z^G4J&fH%-'
    'jWPJRa;UH_w)9G(QZrC+<m%h}BF`m!Zt-'
    '$N1Ri7%0IX&_>Z|w+UoSk|S#9r+9b^qzq5l9K~RHQ{4%k5eQF(Yo3}r_tlrPaOb9&ujbW~44R(`QOZr=HrT4Y$e<iMQGQ(5Ud2eF'
    'VnNj5t41E${j}ZJ9L?cX;G-'
    'mYwn$bfW?o)cO{Ik+AFyU6F>d=RN6VgMvm#X?8tcEqY+QOkC}%NQS1q`rOqLi`9<zhe{QOrjnK@ICRWf5oLXj}<=YvvD4Hd^&o=7'
    '(DqlftVs;o05%Am-'
    ')FwShSh2k{6_a<y##2=k~Fq<ApherqJ%sn)d(CAE8^KT+nbpl22K={<=h8Z10M59MO>G~X@7db`!UF<Qfy{8mxMFY)`)^m2rHH(c'
    'bmE@T5Ii(&GHVT=;7Dr=}2@W~_0Ngt_3;E(kPN&*270x)~KH?KuYc^?3b;gluPJrPSkC29QX2NcTvD|_*BrV9=q#}=9pVlL8UkUe'
    '5jQ_Sz488E~OGCTqQ_pevK$zN4iU^ud`~I(%C~~>y>HpjD^eRp)XG?3eEC?qRO>rH)Y9BE;xn}`V^5uICkljlC_*QGVY1glfI%K;'
    '<R+HR#$<2^se3O3*1CjV%H&KTc8aG;iHy<M@#_I*@xkltH7S3<w*xrtVW9nzyVT(a)2ejLA2^GU$OSPBLcNorSchm2f)>Rr#1H2f'
    '|8n>YKf$gF+4%+p+%Ng_@-'
    '6I|Sn2}|Scc45CnDHsZg6RStWpicTHQX)6F!hGfgrn{uzHMN*g3W=&oyR3S!vbS92`pl<mV6T)*N8tl-8~Oi%XJ9(cNmbU@z-'
    '7elhwjCrnlaz&i1zE(1_(qwt@sl$Kq8bWBOQk+xn4Y6{C8Ox5XuQLTv|!W#6#dk+9l9DD7AX^ReAtzh->OW3x?-'
    'n3Lw8*D|bm^BYp?O7DO#70M8=ZqGz3yoNZu!JaShfO~Cvh&#Z;>QadqChTl`y2oU6;hSh*L1!C}bavPuO`3_Te@?q?k^-'
    '%v_IJ4TW^Ow>zWRH+z(U$9Q0=De3Pl~Bfq`x97Zoi^6-'
    'O0sLFkMOEp6i(`bm`Q6zFRQ5M7hGj_m7q+t4;6fIAH;3dld6dYn<aWHDULDqFTwaB+Q~xHwy|H|cG7Smkgq#V{ggH*OO#X<PKBHX'
    '*?@g+3khMy9ZIga#r{#S7pzLFe`GCDPqN<VR^<8YO-WNeHxMRYcTh67@F6ootC4eivb(wk`>5FSh1-'
    '_H`M;9Hp1^M?s7`rzc|xlPdF<Zb&i&z>u!!#9?Sz=H$!s)&oU?y6V^CX09ttMAmH(zdQCW6SdZIA)E?Y|J5G<z7h6tN4la<y$#|2'
    '&A3gP+t9xQG;#-x(57{|VVlTc;z`}Qt-'
    'jfM34)Qv0#!ATR%3mpNvjtubc=#665ZNdT0YriH$(T13zU4nIsNQMbWJSYWu{G#`T-EhoT-ZzkN1dBV!PzzsOvTbgS?Bag+Q!2pS'
    'P=+`>x~|a3Te4mGvp>gwC5q>6#fg*E-'
    '+npdl5o+l4j|<1Hh_jk9OI(gD|0I0L<_($!Sv&+Q<CJ6)B_d}b&>y|<OEG5{Wj2E!c>q+_ea-R_pHnWn9B_A>dRW@7lUyv9v=j=9'
    'CajGO;(%A}dD>etJKtSTB)VO1-VznE)s0^`q~3{;+M($m@u#!r{|^#!LaR++phH4E1=d5Rg78-5%U%96?T`d!KO`;@+zV#e7NxM-'
    'YoUOY?|c}2PSI5>q$08=Nw9-'
    'aO?ef9d}^cX4pre;04&E0;JRz;uN*1&P)@Be|o>I~*Pzauo&n8DE$kCs}0O%p|d8u}oo^S3FbRfh|dz0F`#R3c<b_^Sh`qYpA=eu'
    's+hh=H!MRSF*|WW6>9sBendRaF-'
    'GADEDyEdo+C1{}G``jjN!9{qHD`YR=cJ};EA1w-MdA}91AYWivQSv^S?I&aKIef+}@=S3_Nbx-Ai#w^7uO;cu8lhX}Dk;?IOhXlb'
    'p<OGhV0XB^>E3Z!Gt%_grPZj1Png)JbN?*$1tE#xUy>*Q+o=AvicFMc?iUx)mp-'
    '$;iIk|H2Ku+m+Pl@5s@sz&$N|f_~bt{ZMf1(1E<8W>q^lCEi3Jcln^3qLPtD~1=!S*b$SSw7L`{jWwZO@zgr{s~1ridMVzE1*P;h'
    '|ctYB$>uxqJYVrCFq%6OAd1i)}lke_^Lj`jb2dcTGMvu>;f?fiZTFsqL`gU~!t5b=8zlknx<!ZAW(?FJQFS?B}R*j@!I$I&a&Z)3'
    'xa=Y<9)1%RQG7AC7++zaxvtWu~ofv}ep9xHkdSK7U~Ah@gxenY*Q+RAQ{-'
    'J`i$1Ih;@Y;l%2VBE$CTMaD1hwX)}KoCnu6=^S+#9F&wi-bFf0i4G|d8x!-'
    '6&IE}``K0%?b#$6|F_q#c4D+%@3pyyT>3TU{VK8*=@Tr*f1(m&_IB#r{rfkTV^7V-'
    'vDRr1)Z=76~>iNT&6U++qye;qfOLwc$L|r4T85=-@d5*H23?Ib2JobR9+Hzk~G`X`be4Pb8ml&pA+z&O7kZj&j-'
    '@CV@XHX0rQ>dxo;2d(M-'
    'MeO2uy7TH4;Q{H1+egkQG%xieugzBJ+BilybIQ$<a<0w?>TvEae51f?IaS#j>S$$p>gQH=E<7ax@t_ZbJgXDkThQsNJ^9Q2guj>b'
    '~Yv^$JhqY4Ic11mW7B`;gYy+(8eKeVMEubE7ZC$_4V5+4drf{muP4QUn3R3YSWY55o8!t!Ug2>6y4YsNnXHh9)@{|sKZ=7VcZ^eB'
    'xdfR*@&?pbjnIPg?!VE)6w8fiQ3QQGVmV*!l)CyLdgfd#KYFBc<VG*7b5DWX-d^~p?r|C(yhZM)*0iJ;URN}<St5o-'
    'HNc2io9d3{)npdN4F+|Xx!aY2zoEGV!g`)TZv}xk~8un>^)=hSu<;v=X#<Wv3ADS&htL=02mRhbaH86gVeBqSQ7c;DC3qfB9m-'
    '?06Pp2A0b|}Mj>=^k5nk$`!qSG7jLcIt%)G9k+|}CaNoqQ=!hc`<kvc74z<wmVvuBjBnIfS%>ZX9y4j@w4d2dv^>k+O_ohJ4>>OV'
    '2_-K~i6`#Um7~{8SZWcI++0`J3Ulclm^4)6|-Go_cutiUEEU+<}Ft?`h;$e*=JiHJ|1tL-HvPhLD?ruCYD?!}Uix+B*U?Fi2nWo`'
    'e7~a+_3S0vBl&=#O0a64tcm0%@0l0hUcLUpVqaOUYnSA;%LtY86$|9dp#I+JN1BzrPxw9cvcAe(v^`J`8;{bk?o69TAOE+7hPXM1'
    '7%2Lh}D(#gYy`SD8w;YL-#YJV1eo%vE#)4CRZo6JAuhD@fsK=e`ot^Ey+xQzUu8ZyI{x-#)-'
    '8x=;<M0#%g@Uloacq2u%K3t7$9UIJyoox`zH;7mT@D<!sS(mK`Xl0OZMF<61v?nJZ{zA)M|mU|VngD_3f(vqCvrg>An6~`jk|Gs5'
    '_c7P3<>B!JOT8dve;qJ?GIVS&}#le7D*1qlQ44yel$+KkQ8pl2dsErJh=V8F^x?='
)
)).decode("utf-8"))
_V43_MODULE_ORDER = ['scripts.v21_route_memory_search', 'v19_terminal', 'scripts.v19_terminal', 'scripts.v22_market_impact', 'scripts.v22_weed_repair', 'v23.state_encoder', 'v23.simulator', 'v23.policy_library', 'v23.planner', 'v24.market_maker', 'v43.sparse_router']
for _v43_name in _V43_MODULE_ORDER:
    _v43_load(_v43_name, _V43_MODULES[_v43_name])

_V43_ROUTES = json.loads(zlib.decompress(base64.b85decode(
(
    'c-rlKU2kO9k>r2r=Xy|mkWKAdTdJ`eZmWfsw1ruN5RA14yVxBs;Msi`4CcRYtI7Jh85t3o=M>eF{UnM_7SBERd}KyOM*PRCKmX-'
    'l{`CL;_y2wMU;g+Xum0svfBV<J{O#kHufBcr-FL4ZSFirZpZ@yifBX22k6-'
    '@lpZ@m0{_@k${qfare)#7fzy0w3>mR=Q{?+Q$;dlEtAOE|1T>bIY@7{jczq<P3r=R_9zyJE<5B_2Q?)^8fR<9S|e*XQt<G0^@^Y#'
    'yK-hKRs?|!%6fBVx1KmO<HYH)AA`uz{zUjD#&pnrUI*nju^r@#Eo`w!p$?$zVv(6bLZKZ5x|=^QNn!f$?f`|j%>KhEa&KYW^xi;s'
    'W)RBxc~-h8z`J@D1XeEg?xzCTT__i_L9)5Kpt>znWQA3pu|;`7L-eDx-'
    'Or035gzkU4K!ABtz+<7K4(Wm90pDoVsaRg86<kP2o`nb~c#s_--xY{&-'
    '_x=a_Es^PsZ|nJko73BPIIxcWmlWqWz9jub$H|0GqJRB)y!h>?6$1Wt=cW8&x6uBLn4sk?cKJY0ufKUY7+1j^zU9`B;z6%JI^L(~'
    'V$D8#`3P%zzgg!kIF(K>_4*6;A@AS4+kf@_kN>p)@cr9&Z~xn;S28*>aMCq~7S~-'
    'E!{;+ky`hnt_q?|{XCVtKDu*ICnV&ZD#TRn#tGSCG**fgw$H;>vp84QI!01N@CZ`OXx#2^;{_y@=`XNt$g@4G?7uP4<cl&og#rzi'
    '!{L^uTj=8Nm=C)Z-dfa&E@54iUv;0#}kI%Qx`47gwQ%gXykjS6H?P3bQ`~Jh5!*BK<KKwJdF2KVb-'
    '`K@alDTvK0DoL(o%kd6Kg7T2v)kAYOG`<gcY7D|U2-Xv?lyIOgHu1=b?%k}*H!P{^RA~(;?Q~*ok{Fu)l-'
    '6?;{kNBy)VzD#kX5?*b5cJES|He3N}HLy7LEh(!2AqR7V8ZEnk^5=bmrC6P<{v9;NBG*NZ?(F@+b>!1Jwg>(05u1|qQCF?<M*v3>'
    'kJui`?uV_nm7AG~aiT^N|1WEU<i^Db^&FzEQ7HB<UFvh!>f&=^<o;<uY&%SD25+xvHTjh(OGa1qz;IrKsLDH*zY{z{%oG#q%oZH$'
    'j0*Df1OdH}E78-`rf@C6#rLhe|9Ld-k%`DVFUI+$P&FLT3gKhtpFRu}WBxck-'
    'ngLNmL{_^uLloA<!IfH+lpH5E%c`G*~O9U%dBfEVj-PDzu-Am2YvL^O%6~FoLUkA%qpUPrCE#s@FK7DYCshuiHa!#NBY_FQCCinT'
    'zU7YZ(O#0%k%b?TJmEHqNz`!ow@OhB%^>pg}oj1aww0XN``B6@-'
    'fJV2qy+V_UP8})+C+J+zpF^MVv<VCp==qo6CMbN)^1ixDFX87v<MLhuvBw?0rkyX69D6$gg|Ez<v|n#95%g8_BKN}q`mI~!^vy>q'
    '<@?=-Vl19py_xw>(ZTacxYB$(mnSbch12hL-cqe55U>682WG(+r+_6K`sTf^-'
    's$P=K7Eno)A0w<B$UFQ(<hx`K7?&lCe?&p;<FU4Fz`2)zb(IN@EEMopO(vb*&>~qh>ySrTHfHLGJXtyP6*0*6yRGvQKSdl!0&*$u'
    '5dwiefVVMab%LnsSuhKhX7|JdH1s)KeBt4D{*tfCm#X~Z4|0gIqFe4<A66f$bCtA$ZA?qsv1Mdc;+0Ma7crPP2-'
    '{3Ic|u768cu74uPYvLmHShL$o9u;W^k46($56D^^-^E*rQij%eE9{riuH(|z_VOQcF%ILA+`k`$f?6Yi_L-'
    'p2`}=}B~N!swtpgRt(?5YD4It^L!#CHSOOGr4+8>rIC7L=p?FOBwvw#VdWtMs_)TIXnyyhOfvtHu(MRYQV+mNF>3m6<}Qq%6XkJx'
    'B$UpUSSpS#d#-}%5k42@J@{?PMKuxd`!^3epQTi=q4j?OCEx8LuYA3@AF9y5cxy-'
    'k!$n^JrzReAF3e?g>QH17V)5(MIp@wZ*8k?O`8JT;7>0I^revf`Jj7|fIT^8H;=vkUyycOh8Fv9_J*JD@B-'
    'tO2SG#}#b77U`PWZJCJGIgN5F7<Av!tfIrB8U&N%~u9rTFFj+E^^jN6ulH3^L?rUS*kpm@&21%trRmsv!~W6L*dt*CP#i~kB5knR'
    'aJ)>M*m<r!W5wX!7!&IZXB?6l;ejD{4w3#Dap@UeuvfI`!IkLSdo6Dwdm^^2IT==~DsXB}tff%ebG`1zoaf(Ve|44-'
    '>S!VoAKYwt{?rHJ++%xWI;Fa!%7B~e~06(zE!ERgF77qJa&A}EMTuy|LN5M^^}zUD!rqkJK0^s;TzfYGw3ci>)!+#5v_3H=_uP@L'
    '!zyf#rQfR>Zw`pyf!?`+b5+vyVTClKYt@@y+YH-S8K8Jj;RQF*dkY5WW>jgI6|*s6s9OTpijl-'
    '(1C7${Qo+5DhH5~GIJL&xQJdaIXUD9ET<tuElt*>5oU$)wOSB7Bs01BqxDl5;v+AflNd<6<#uqd_a=Qz*)(2ZD@9<I0|}*JCi#5a'
    '<Ab5cpt^4pjQX;6icm-cDyS;1Pjnj1rhi+>v8H2U=t2Tqg(cD@<NqPf3<eEQKu@LN!_vm164@yfBStOmr+Rvk3YwSwwSy=j-'
    '%lMY`j-'
    'luO}Z0R;s?y=I$U^TGL_^vP7MJtv>wVLC@VEAed~hnlx`8FmAI5Ps863GPzq7Yc^PWaV_KrC9>1lIXt)5)zRaz;CwddvU{opb!Ku'
    'G+*c(u0HwYG+q9$j8s$!*Jef9tcrwf9X+Dgdl{o5@ZP5FkO<O`-'
    'cP^s_1oXV0JF9Z@gG6cpfBce5<AuEF;J$p;B8r(HMS<jqbM?@L00MadsznrZdd^MMFmsfJUpAtFH?=mWW*PsdI(tU1Dva!emRDS6'
    'ZTOhBzOKOI2385+G%m1ELM0LIuxQ7W@Dd*K8Z;yl-p$3j4W?-y*NabC;r#gC|Rgf>5@LQpdUiO*nW#~$<kB;Pz<-_AuQ%+UFrnk-'
    'PbbtStpmZKin+V-xbI%EEV!nr@q{$-'
    '*G!wG{M=Eu0`mUgFM{<R1n>e;P=QpSgjRX>=Dsr#4=_SeW;u^;k722FR%j$tTija>Fsd8>c#YERJ7Gp#;#r$Zs0O^F=Z0g&>F%j2'
    '_jp$v)xw+=ADmQ;kHgQPY+I3!2#+-'
    '^eI~)R<us4=X2)Xi8n&n1*Yiq6hy}~X^UbxeH^dHY_(f~SnV(n32cT;r_YBqm;vY@Bj*~!<PGv8rCG6kZJY_rADZU#qTBP`eHc<>'
    '0m&Df!}I%!1EUL{6;aY1@YJ8Nk~`W*1|zDWQJ%eyp~wcAq=y}^1(V&&UQfPtN)due5@R+LwYTJ|CUedPFV_z1Z=|<TQ2Sy`0R%hJ'
    'M;?eEVweM?gt!&Zng<7w)n|FRm9v1_siqMm5zXmol<Yu5zX(7l)U=r#RC-'
    'I-Z)?_lVj|NuYUOa_fw48=-iJsyD99?d=D4T_cmf=|UhRA-'
    'Ho@P>Xz<F8M%sU2iBuTPdh*256vyqNA``0xj=DqyGDjFBFNFk^@t(Vs1dFaNf|8s*BOJ{w0LUW>e0)hC-'
    'hco6yTl_DyN`Bsd?k>?@FRMbkuzFNvdcjzT%KEfc?#f(t{*!@BeOCTX9Dh6sZE$jM6Sw8eho!BRr4|BG+Ivw-oUtuiVFPA*o(Iu$'
    ')~m72)H}JVNhub@pDJ|YAf%=*%sAKw-6mXzeT+rq8aJMFHhYZJS!_tbhD}77N-'
    '`RlJk5aoReHfm#JL*u(Vga6r3?4E=3*C^d1NKeC?~P6o0G`v2E18;98kr4B%UE4RO4&bJr=tavT_X6yB%Hl0z^FL7=(ylGfd>YW7'
    'V0bl}?_Jh2ZD8`UTtUXcs_axbL9{z=hd;-'
    'MB9tTee`ZR#LIj0s+g2zuNX6dj6$1I84EqEKU_ERoGn!%r9nm}EfbNxVgSTwfCKM{qif;e1)?%QCYjZ7TpUU{;?$WH@AH`L4m1vt'
    'uk(QofJV;?cDvW+J?jU2CWvRVTQmO$<_`yyM1^Ruywx$DwvF$4GLU4}1oa0QzjW#O|)naVo=RI<9DT`LV|+3cu!~b^tG+HP&bV;S'
    '8OswycLxLFLbQnX?XiGYQnhqH?XjcAc}rt*f)!Dea>^92Ibw>GV*B!*&*>h~Z>w#MA2>F`*s8(nr{QrE{;U7Oq-Sw6RKY+YXh6bs'
    'qt_YU)rifFS0h5Z<;}8X&Imq}fYI$M`rVmjJ)xEH0mcL=-PZkf(qb+|zVo$scQ*QSh}^GjQ>7V=vIzyGCSlJCJVZTiBmg3y-'
    'f#%P@JC;c)RNH|OZ-qVOh)MnAu!=Icd*j2^)JKo0v<dcxBm7-RWxw~>?xy3-vZR^EGhL|g1&)pdG}ZzE=n<YkmhX#eo`-'
    'R}W~L^#L7>8ww@l?+$qjqQvmPJEp2I6~4d6<+^5JK&$O1L=kY6k2-'
    'LGRKA}!c>|EN!&B^x>Fq(U}Ur>w4SCLwl}Qk%oWm5F{YzFFj7J`U0=q$T1MFuyt>5*>L4^53dHKb0E1~JwWG1N7MEo*%M!<5d3-'
    '!(fv~-ghxrSXszVot*&@*(CwPB9{#2gb%%mK!-BE|x8XA^rZO$y_?u)Zm<N{Eb)GCSkL-'
    'p$TjQ7dLqj0BbJs?yG$Qo;`Ja!71HYi@3$b*M4PL}Lbs!Bw^G4GM+sa2B8ALLtL22)g^J7>HD9aWuk&6CA<<^c|+86^X>Wl?T9yA'
    'tg}K0lGe;EN49#T?K%Cg1N!S}lb=?q4pgo+J~w(_-hUgF^_1M^pp-'
    '%f{1CXHyZZo4^#^cdGH$Ra}7p=AAJkRry*`+iO}dUgGPvbQDUmJ?#=FeUmT6X$dbCB>RbOL3iH{)@cGx0&<>y`!K#=i}N-'
    'nPrw@lYC9fQyNxD16yNYmnWVHNwD)Oek6H1bl05S62BC+KSMPO=ldwJNp#W)Brm1eGs$W2pe42u5L42(0KxWEf620Y;&AcsO;glg'
    '0J6_TL#@T6APEsix+0^SIYty9yoG6gXByeB!ey$j8yTZZEXe}To&v(Y9jOgXMibvZm^mnLBhUbikBA6Oig~@eWxEq5D%(6lA{_z1'
    '1MntEzDt?eBE7ymV=*8_5zH00YUn7TuB522(oEKe8VJ>xG*68a5gL2qE$u_?)$(r&hMENcltjTzy#0pyil28y&Uqs2%m~}=~l3eK'
    '`A}{ep024QGL*{gs^Y@Rc4(rFyq?=))imK>gNH7x*rWu4{t`_9hMx(arn;zv@P#PoMqz*jQAO+Y`tEiiUl<Zm>n!MeCfv74was+S'
    'd)TC|)MC7Gc1FqzG*{OU!f>!i<<s*y~3v_;KE8y0|P1C^=(6pA!XK_4RdpW`*)3CLBB$4(Fm-gW~;uaJ&D@_}h;x)^Jo+JQt%-'
    '3(oS~ja$5HQFHP_DnOa9$Mp#Zup=>D(BxOuB~{7wW3ci|&?~E>Jh`F^(DGM|IL8{uNWpF5StjaZBD266V}%4t-'
    'oB$M4L!009cYv{B9r<9Z{P@zhe%9}Q$_8yR04Y>it+sFYU)l1#CNsO&$Ne*sXfj2)hqk8v4;L%(Q2#GVy{j2Y}mw#FJf8~e_1TDX'
    '>A@m6Wo(pPTCg{xGbgp@Yi3Z=}!8F4g2qxGl~6HnfT$r7&n6@Vqq4>D+}et8Zy-<j+QQBbN8#}Kewr!|YJsY>k^-'
    'zl~AAe<kv5h9*Mp+R(4OMYN{6Oq+R+M;-T0P^_G1@voH-GBhgRwGth6VxKcrmNuQ!oHI%b%z)P)@qj+WFT=j7UZZhC(6i=!c5{Rb'
    'otwN<Fuhz%7y_REu)Ni$r|(^##Syz%q}KB&Ka^pW%z@h+)IHyFD+6s5ReJpQFE&Kz^C97?G5zi`r*pCtnZV+0y7SJyZV+k#`i@yQ'
    'tq8(VOUDf2;}nDVbFSlk0{i@t!Im<RfA$qKDOXJmCh8cY>$|uvJ2ZqaS4iE1JCRC7W&g!@?z?&tJTBq=dMAvZ$<*9KYQLJ+3D~Q!'
    'Q${7UX)c~L`;e+X39l}mean#%&3+oBI3ub1!+v0D#DaZ9POQFGk6L@J3Pg0=*p{6G6@!5#Y)qeuB$Ocq`c%C7Y6nki;6Koa*$Cz5'
    'b($g!!{c5h6RGSPE8yf)fr`^i8}VxoxdCgI9IpQ9~qtDU!E`u(Z#9ipjIVPU{lO0hh3(bFViLKbxJ!9Iik=|?DlN1g39eb9E9<Rg'
    'O2`%MRcw`$5inP*TRE#wG~M*tI>EvcGt?7j)N)njJl=Qk_zkCDi2hB_QuN?&ka_+tRoYJnEnbIwAM9s2`T!XUqL7vE8m`~Tr34-'
    '88s<;M`@Ou2x&>GMvTY6G^?UI#lxIL(<r%?m=Dx*gNp0mZGyksXlRHVn5U2y(@t<kswL31-oz{fW5J6%k4bA;gF0YrP9}-'
    'vX(AOs8g<6VUJDQOh*}XY8zAvitf*}ilwjD<nHC0X!glzvPUkxX{!y@S8YXxcQ;1qV(7h3*XEY#M00JZRSPceYuwJC!$o5+{UYcA'
    'rib7HR6w!CJ?+%R>&1yl`gv$v^_nNZQrA}-u{Lr#Y&gC#lmu!4pQ9sxk&*d$#_^bhDKK}l;*haSgoZH9-'
    'v7j7h&2^PcfMk<+!(%v3%@KT$J&cIf>1#ljr>es2laax64;?}$AM6S+1!QXqMBYa7qxQ=xU0MrrjYvsI(C!Nmly6H|RvU}R(n+PW'
    '2PeH+N!4o_YfiF_a~*7h3X}AtR4xo^fv*OOhC=_*Q+}Q$Z3@>g(}XaWN53D$PB0@W1ovP7;DHOvT+rM_{^0CMG<AKL%ax60*0}Se'
    'e<C^3Qe<Jv*->aNmb_#05Y-'
    '`rC=s*kVG3Jr_usBfr^Ks+ws##@H<<N|GBawYOnMIEX#>SZDxOwcVxqv50ZbTqZQ4f9HLO;3jBg%G1RI-$Yu-'
    '@_r>do?V{>lgiAoNrj09HDT_exbXS@-aU+tsd@TUz9)Rfi-T5K1xV$94dJ)-'
    'K$>2zDF_alVU=x4j&YMK8HHn7L$VFF5ddlk9r?sTo2(Z3>YaEVXEZY;}0%v2z<kU^&tbsOd&{j@K-'
    'V8<_we3a`6Nm^1@&}cjLUp5l6GP-'
    '3<$jURUWR^R&j?u;g%Dc`{8OfhAxeMY(gT>;@>tz{^Dw&z=(a2Xb@?QW%6%3oQ7N(`6Cw{b&gvI4?c4zhP_pu_MWG&j^O6ulKIuu'
    'yL7p$Y+qEl^LV|_o?e$lNM-f}CLgq0y%&*-'
    'Klm{pYmYcBd8&ks)vBaIM6W(N}+VL$QBDnUH*nq=U8*JMLM{cuo=QJQR|)X|bl&)aE$iA=7coIQfw<=Q4j34)VrUza$O*Uj7QYZ{'
    '%D6(mnQ_@Rli+axKkv5i(&;25t#$gb^>yzuQ_VWD+A*nw)tIvz{P5{e)aFznhD{fOoRKc%~O16(T471z9;wVZtExeVH`OTi)(d@c'
    '1Y)w=abK)6^Gt435j-IPTxA{P_8@6xK&eUYcdEcsRuRqdQe&||{D0&fJ8s+d5&iiS-%Kcf;SJLDHioigAe-'
    '=f}yoNj`CZDjMSgKgQ}Zc{NYb}7_aRC^LhIQj)>7H25w=NSm%EK-#b(z6C|@GGUuCTYE?<myU-HUAU0utdWNI7($5Wfu!{7<LO*)'
    'zb`@DWv7K4x062-&YvFV1!QXy>=jh?+&w3R9;wbTk;&bvqDsR<>v+KWKm??6<pwjd%7W^MU_#mP9WJ^Q}dG-nnphOz^NS!gW}nOI'
    'R7h_eT};*CJB6gm6B9iNHX<>`L+ONRetqFmUO71Dee5MGqpCDsTCIwZQ4KP@z<$ZV$!76ep6$f61N}@%X>p9chNdpj|``kOp<2U-'
    'N1u2sbkXMS|id8>Pqg9p$Y*uTF%1h5f!K&+uo)U@iME|i=viaOxzyYlG+S)WPyokHs`mjo7*SqI@3msgCp+>P_iuPAk}gTY;oo6W'
    'IF>Q6s$8}`8njWR8$wqKt-'
    '3(*1$W1xIAx_%mESb`cAVT>Q3hC{Onr=Z>i+X>X)XQI(Zz9D>^FNRXaGV;KF+y*Doo|t>k`k*LC}nDOt$HD2%QZiZBSjZcP@MDnc'
    'W=0PX27>RLDIh{BM)P*~qP5;V2iVQUvxEUk6X+;F@yJ!<^OS8ZsMY%cVTC?+|n$&}|=u7n-'
    'S?pv|%0GSXbQ6nx0eeJ12e@61y#Oc@AMf{dXiA|tt{LK3B_S3bOgBwb29hr7F^#nn|S>Ylq(bzXiFpq{nlTjFkjl9yOZg1$cOY=h'
    'yoV}7)*%Y-pHjl%yk4#_I^Up9edyQmIi;hHL89Ej4w9as?Tz840d^D-'
    '#S8U1ag%*;1>o4DRVWR?nT9!VyA%z2gEeP7b8Bc5k*$Y`GrWr>=J3<0wAo~8@`)>+1-'
    'rZCUWbZ60;wxFVZEwM*^kY04JGh_&Iieihq|24IOBLHzZZ*WcdFQ5D_$)iAOF52rf@8aEeypS1pybO?L{JG~l5mG5dloG5g^YXYC'
    'Ze0QAS}O0WKN=Jq9$gFH&qeoc9h+=qide6fYVk5XF{AC*Rjib_y5o>a~uNu;AE_?th;4A(S%dOR*i>lv{#KOk!h%mC!7ZFsV*TAs'
    'c|uwE6Swzv@m<EYphmX=N`5k-g|^Nmyl&il5}-m1Pb8FrWCsGhGA-'
    '|A_h@uVWC6`m1ELNh=A&H&fQzE25mN$Z^VrJ0a+Zr=HfL({jAF)hqKt(BG)k|tI;N<nrgVEG&YgB269g(9j>Y>=zDq{`!qCgrTBz'
    '37Lzl^$EOuE&P4;aw77xsHe|~APCpn0Y#1LcA!MbSK;)@f%dMWdmYtU1Gx<iJR^|uhp-'
    '#LY*o?H(5!XEPEHJSq=eXoyo4@0mHd*tF>A89$LOBrYYOnhrOGaJKHKmH+dx5b;94)+(=PX&SdjtIQyv&+iUpvX^VhlET?+4$)D|'
    '`*JlAnG_o+Uf|l7aF)l`Nw#FlyyTnAaTo+IXW24bq0E!9V24+-'
    '}RAiN;8su99Qv{VbD&FAxJSBeUPU5A?9FU|=4TYKB##lsRLC#kRj-'
    'F)Z~|oP>~6_?LKD|14r>x(A3vs0G}v$s;PXl#R3}HWkSzf~#nQw2>sC0ibqrfBkaN`nt%8x9v*WW3eexw~Y`1#O$@-'
    'MrT>4M5dW2XVDD79UVEb{18*#5R}!@lMDm*993_p$}a_6j_fM}$|bui5vQ_P=tilwEgPn6C%Kd#TgV+B8HIT(aQu+BEsA?%Jdvk;'
    'x_;9<$ms~`Q!!x~)CptIteKH|oX1@;BHxw2KV4Fc@h{L0b9zM+5Tzp!W;KMs<T|3KGnO6K`C`-'
    ';fcH53rh_YmU{Y8tO)yKHEIvlA$u`*D0`q(ovjRRz$k~~H;gXU#*5MLeSQ#OiI4#B-'
    '#RZMF1}<Q_9RD5ZdGXG_O{ZOOV`{7!ZIVx<+%J<i`}$>cx(-'
    '#s0c(wjY2&7g*a#snN_`i4DcLTrqfeuTi6r@5)><q$N}eOHA4^$sqWsk{R#aujz?|(77-'
    'm>4hM}m;#DlKJ*>MGpFn{7jFC)(x1CL<9l2K!{f<?e4U+VJvDo>_!BLi`@jQHg;bh;O(NMZ*}3<*Okh>lTGXzOX;!O@Zj^ZA)3z{'
    '}p0;@31tgltPzuyeDUXqa~6@eXTx$%U`#vNiXQ<6J~=>&L~R_Jcv;8aI3d;FbY1)>XIwS48cN$;OYi!?62s(*yxsUNya;9nm(EnX'
    'OaL=bUBJw}z}Ux;^_rr|rMg>bjT%4Rr9DOI4}Bv$@x|KWegf9WDhQ9lP1bKFDwYM$n^&86RxVbbx@7Fogv(3kYox90O~cIVMt>vx'
    'DV&DThrv;0?7pc;<oC%-'
    'L8GGNULTueq5Z+cw|*HzeEr91vX0!fx2rr=2uBgq)F_)@Ab3s*CV2T79h<F#Dn%+<ANvR~?!3`n5G9ocEDveKrgLoW#4_FV;}Du4'
    '^u<=#~<bXvw_u2BWUea~$YgaRytZ(H*5ANH6_sZ+(JH^U+v>VU3q#vpnNAf?*u9kHk+C6TKOtW|Ox@A+0Mc9Yg2qHnx$}N?t;T`k'
    'i<YYvD!kP9p12E>Wi}@qLSeYW9@Ya9G+6%o-'
    'X!R+Mk0mWx@LA|$ds%7ukf0*@&nG`}axcLZT1a#=%C%Lm}8pye!5zl1qJhX1n0MLjY|wUJGI9>0=eB)-'
    'PoRv+4dj>Q`<sjCek<A5J>cJ9-l?^F7KCWc@Jmx{1`W-'
    'pV@5k`HrjyW2BbG~m(4N%@g1d^CPuaDZt{x!ctGeRV;tgF?<!q?f(ASO8w>#o+Icvkj{&4snsmcRFs^4wN;Bx0J=afrb1*?XNSK5'
    'mZx^6fla9*WUN@YlsK`+4B4(&Js=ttXHAO(JV`SH!xU3vjM5787i;w6f9<H^dcta8k@_DUK%aiCRx#0j=p{PRCp8d3k9wO6nS}$R'
    'V{iS(4=POT*xiFZjX>ZJmoB0=i?4B>i07Bk2l9NFf)`!vE357lzvLU{zlv29yLt?GJKgmYEDaiok;saKY^_2eU5TT#q3(#}AVuB('
    'Vx?(<^&nO%kiju+8MEVQfQz`Ownll|G%JZN?D0i>L9R41a-oS>GvpD{*Y9U7X>ybY$*IPQWu{&Aho+!jlI^gu3{gvZmFpZPJ-'
    '&Zq71*b;<#70^<q5*6jMRC$EO6+e^&4@G4DjVu^-'
    'V_}*PJ(1U{;$2*0k8lZ{KIBy<qq{mhx@hYQ`u4ejK9Y~(D)79GWEz0^B86$q-'
    'mB^kp<M})!iSp}|%up?Y_|U24RKq(}d8sYRbhRBZnspUs*FvvfCfVhd8p(2L8D1WwF{RyN>|Ipd?HwH?G7pLd*ay8p0HG0pw%qaA'
    'eC5U&@bpx7#`CkYF?_2cNEba4ObTS=h|;13==X3IO-'
    '!Zo$6oVq8T`@c;QsgI$Lje^@{WAnY3wl{+l<JGHm;sg`2MDluPA!jo^8BpV?EcPmn**TLyBvQq)&Bv=()K@JU*94htCi{z*$$|1W'
    'XBFNzPYyer3IUG&Jat+=gu?Y#Ugvs8(;=ve=W^HQo1s1t*&b^({W)u(fl?29~w!5xHy*ip?)tiJUstXG)!Lx}H-'
    'yAF>rU=J;w76CGRh>Z{8hXvD^qGWslgK$d%z&M#rm>RJpnxQvqO1Y+?AEdf1Z!D>p8Se9`4J08dRT^rR9^HAdqi+OsOr{UK&MrCf'
    'G>{yVV^3?{d2c9=)dU{uEoW*a;l7Vfz%336W{uyiTSZ<Y)+B-;)i^h&D(_#sv**i)2=$!}M7-'
    'b(~#!7Rg2#&;eTT3w<wYybc`l9Ek>IE?6*4PSbzUZ9F{2#zeBm8KqXE{4A4*RAlDwTSS^9(qeNJ>>cK+mq!RH)2*sUwhR&3Z~B1Y'
    'z(eW+C{Y`$8+|KNzTtfvP3$<V(Dx_#t>>K)i5_Lt5;nrmV^IDy+pZLw(5Q7HrzvWorJ7Hy%4J(;V7J<0#TxV2DKa+*jT92M@q~Vc'
    'S)Kc2N-=I_C*OImL<9FZCPPL}kg$@nv-'
    ';RdT^38I}?*_pa)^($Ggh1zmJA);DT`b4{5YsiStYZHouV;SBm!fg5eggi!}psc6QJ!ioN?%#lEFmZ)+OH~FXwj~2F7i*P9TO#_m'
    'C8;yZ6qM#yP?}z-R8RHKe4y+6RP+!L#1DGTth4UH@HS@5j@$w?zkbNg3v!(Fcz4f7fnM_3nuDBsP4m`3`=u@R^fRcRl-'
    't=~L`CM#W+)8GMmQFbJZeL>6_K~!0#k-Zkx-R@h9aPjEvo@M&O?%Frz}Gwu9rME}zNZ|S-|-'
    'gVoEWz0a_b&!vf}!&Mcy=dcnsPE?`82rwAjTxUct=A6)5O;MVC3bC|;U!Cl6eQOy(%=IXuWVZ-Lbj86VmrAvkotolEl*0=HDPqd@'
    'X$=$(NB=K1EILqVfq<;s}`A$;aDW@QfJ`XaKvSx*vLybep)(I?5sP6|P@ps;~sfNC(GUuL!OUQ<(^lCib@!kL0DO>vTmUeA)pP{w'
    'LHTfmolKC3qGZ6*42)tgJ$iWESkl`Rm?!%;-'
    '2{0sNcEWU*aX1XOBm%W;j@iLh=bygg1w`RndE|LPet*Njbd`?FFBke<OPhcsl+3F?O>UO57EN%NiAKs(y^j{!t-'
    '_Q~d=n5IVpGiX&tw8v9o$VsGvJbOWe@ku(f5wjiSi_#g%Zo4f=+9|ny&G?1(%;Kkfx7`8Ytm!=i~!Hk=hvp(u2;-'
    '7m<I)Tn$y22X~<&xYIP&cJl?@iokZEt_r5SB0dtOA?4OlCOczLO0^S%HL4nJ9{6i0hmN1&PmhSNL44^5U@&%mI<LEa#M_SKXNSUP'
    'O==x1kzK@Uf?|=H+Uw{0U|M|Cn`{~ixltzo!Z$G^M`iHN+mx$m+x9>Aw>@{uzzB_*V%{OoV@aEHe{BFPhmZ^fCet=z5g(9H;LFpV'
    'U{=#p5c>C__A3x6K_dn!Z1Y@Aj<o~A!URtn!Vh2A>ZkMPOn**OeZ;W11la=p03Yp-}Gm(iN(xA_pG)mLkai4Qsw0hGU-'
    '<EEIVbj}qIBm>Rn%}e^sK|_8l1EB%mdm`hsJY&FDZkh)q&YJoFj&e>H7^I_D!5CeE)+}LW~v*X%}FjTjw?8o>JC;aYif-QoOF$$d'
    'CaBHWS)9MBR4P859svM5)HoE$(*#Y49s2H&{I5c!^g;jC7$`<Lj-'
    '=;8JL_haOQ>&iAko98aQc{p%x??f3}Lhj{ZJ8#5YFvP6Rrn$Eip_r1Y29m~}CQG><0G1ozQ&{{VknXPx*X_CI92Z_E!%OG%%1dl&'
    'Luaw*MhDe|n1+${&LtKPlmT~D3Fq4h30li10srvyRA1L$IVU!F^gZ@1>K7b@6%*9ta4lR9b<Q@HBuhyc6gE0gBj^9^{S6H(QpH2w'
    'B^5lAVf@Io4RzEy7BId|AV1hzYd58*MkkDupNTnKlpYkJU)d3KIn7?_=87cMRHE^b^fX8&qyriR<va_(;NDz^Hf3y8#x@897yMzl'
    'z3_gqi5grTcU<DwD{ELsG5*KT1j<ld!a_TGi*Kb?7DF3Q%%g*oY_@i-4Rx<|L^J^HzZ1Gl=EPsQD@-'
    'XE+x`Sh2cf1#Af@XHx$cFazvCxX0#uHA<@J^#J&Sa|qNF6!1?Eo)+sLR-zCKb6IPTE<Q%J0eKPIR&Bsel^u@?jN&-'
    'X3CNJT>)BR3n&2t6Ma0R_5RKqVNu$=U6XnOb)(zbUZF`vrw$e48KPv|ea3>$?D3c2CMbN)^1iw=do|Z<CRyHV*-'
    'Vn``w=XBNVRKIN&TD9`l@-u`*8yO)-96#<|CDWfbK&vde5!i%>1Y50R1G6X}+C8H_)(aZLL@k<AL-CU@KJ&lnl8(H0i)eu@(l{63'
    '<GV7KopKsVPNC%=vPfCamE{U%T<VMmR^*qqKmn(K8w7;f298N#p~?_=ibU03F-'
    '17}d7i&`@@qOUNLbK7O+DNHVa^u^VXI^+)DT6dT`e@@z>q(8T9&=qIyfIztgST?IYrXC__0SCY23q?4?s6|t(JRnH2GN__Twj(mI'
    'OuGdFN`Idh8ZS-ns$~HuuDeK1cgfx%n+l4+HSC5{^K|#(PYiTz@_@qefE;)*}7<V^Z8L%y0Yydr5WgY*G%L?%F%hhXIZ!%CQvR+h'
    '+X^~KyxUKNfU;xo<V*m8S59aHts#gxFDef40^wVHJ<|bdiD(Dnh_P7nAG1$kz(&0P>SCyq*M^Mtydr7id@^0b?&+UZ`f)N}5$237'
    '7I(>{9_{pA_5*k*aFjHC|)KmZz^e-'
    'zm{H&n!n>SZ1o|4<%JT2wgOfzG73B#Pn+h}P3StZnSE&xr}`*o|p?{M9gL;GbT@<ufxZ#=V^ZTigv6RSzu%t{%T2fjBD24HZJ+In'
    '<LE*+=dp$=jY<p7Ydh|OIWf^lzR$tY^5tCHwrRw!F6+e1EO-'
    'N~ctBkGA)m=4}L5blYcrhc*z<R4B8rM<Gs{QNF1tIX42oR6Oa_?@sRo^iG-'
    'N9V1OX71%hOog;Mk7{**59v9%OJ7$D>SqQ!^i)(dxcC`T!^$B2H3}%D;6N|VAX9<xqB}i%OyVT>d2BEkpJTOkt(|{6g(~s<VXyND'
    ')1yfSQX~Ox?lOQ0{T#i&U}$}xQ(M1yEP0qXW;cZ*xCv>YD{nZaBqpb3<+;=5ByXcaIMI1V*G;|hl;r4P_BQFibuOj(@6JZvp&F>l'
    '1BSh^JT2`G4TV-'
    '`pnqJa$r9L5ffrVwu^#sGjiYMZl7{ZJqqOhyMyOeOgUam)Q%Q@s&f<vZI9P!l+9@)u2y2aID?`VjiqC!9B2E9uV>NbVPh#gpd(u3'
    'p?x{p6M^R7)^XnGi&nW}&>r!B?UyNatj7;%5D|vh|!SJPquEJ;$`XVE(7xZ)Rn|1K@UW+Dk`(A*R+Mo!#U5$B|1D=w*mpcBXTeo<'
    '=`kste27cqwuZ0#CfIJV-'
    '@z3FS%K<Q=6D5PtHC%G>638R6QjDr553Mv6sObu(<Ax%PTL#rf0BP4YV?OwiG>a}kw6aerv6aUqi&#wMHCyDNVv{`A#rq0IM7$Aq'
    'B?LN1fj<SnF?6~k-'
    '(Zie<0v!HS`XNrgSv%h@=+oV>Kwh5{3w>#F*A?lM$71NMywb^#8mdq+mzuCgMz+&@)S_o@OM+j_!ajIR@lqhJR3t<9)^<vpiZVHJ'
    '`7_upO3YYG>@T=&nETaMbl@sC4|}u$y|HMOs%h$X56`$@m)HDCJ)-'
    'qLe{kPaclNXP&hXS<iUZ@es5A%BcOU4=<o5SyXZbmjqp7(F)6A*$%Tjq+_Rmuk@{L4s1c%LFV#Z`L2wlpzN{Qai=0NvaaudT@>yr'
    'qE3?V}Y!35e)p2jwe3`7I@?xVV->y+$_8g4ykQ=9Z-'
    'c9GQr>oB8<n<R8OmBair1frd#ZcBSITT=_o))pTbFCM$95=_)nCny?Qv!8lby7O5_<Nwd#n1}6SeqaP_;i&ju(N&=iH}SSFUmy!W'
    'ItgfJK3(+s3pqHp1C`)PYp!KQ|NnBi}Rd!upjIZ45P2Ee=`-Urg8%_^(|05qFk*M$m<P_ggb!CmA0a6G4N-'
    'Nv4ZPlZP2)bUA^(br~uTXuos}3i1I%$ZbF_LNU%q=`X(mWKm^;a$vK6(%O49(A1rn=uI6>-kN9N@zwEH<-7Yh;U`=$S_+9O$rp-'
    '?cv2Thkdw<{hYDQnS0K%PF%f2&%G{o{Z&VQL@gwVtT(xqg!bC*^edtb*Ci1&17OL4{$BOIa>7&v{XGhrP<m5RE-db7(JrMMD|Eyf'
    'O$7FnfjiII!!;E|rhIH~QFzR5}xdH%lSt6tp!>aC&DKS?S;;M-'
    'yO+1Zmfs+7o3>{{9<;!(s9MC4xlv1+<)NPVV&&T$<swV|}5Tb}#nHLEQ?I4YuZK7YbiVRW_2n2anKp>NU|OBm&W5IGu<qqS^X1ez'
    'c(SWvUh4FCpI<3Xz+?S?x2!I*ld2Ck(tI@8TdU6vt@06D-'
    'VW_07i^vl%(E9Q0<4(7W&zPp#posAl8Gn3w?nRG5gjEk%xy>`3Ao>;@4ze6$Ug%)3|p_!DuD6Y~^g860HQk8`&S7yQ+PXN;8LCWU'
    'yqed?i9xZ0EY{Z}mn+tA8mZ9BYF8;0MKvYXcQ0<u)aBsGpP+iB9Iv6R{+Z{L7>p@9C2Mb`>9A$I#j2TJ6I8rF=g))>tyGIT&t+M*'
    'yW(WZrr9QfP#=tjHBa+26{s!~2vlh+9#Y9hK_R_}OaMY@5Z@Y#O7@ToN2-b4bGm_m(*%}N)-'
    '+*<0Gn$BlbO@}nYw)&{k#VRZma}7W2J)rh*M@Y#4IVJlmV6<avle{V;TfLxD5bKjbZ@z&@ova8{Jdq`T%K*GW$sMc^RXuT_TBHVw'
    'K%(L=f0400-TL8i2TUW%qLNy0UX@cR1OPUGjYGp9QZ{mAp;0BxI3!l)b7s3-bXc0EMGU9K9)xrQ&$Gf1Y6dF4bcry*(B4@S)FV-P'
    'zRl&ZUs4zx`b+;(oL#K8Z9klftTUzKh-'
    'B$xsH04p985v!q%0m_SHMZChw$4Ap5vP0dcD;=&xI>brQ$jJ^DZZ5|KwGNWX@tRNlS5RvSC;yZYIMJ<-V>pv%-'
    'R$sYsBp+Jn>Q4OlCY-'
    '9!yWes8v*5%0~rCP`#%ybr2sj8ey7^zO`;sghVL^a(e*>yqbzciM<*Z5sc%kl2!lviW};1uQV(v*qa45Nj*kZ9Hlc=y#ZrsL~K>y'
    'e&E5uA)|Gw|k>N3*Oq@5tu`KCc$TX{1B6eNe}%SR;)$r<DTZRvPyb#-rXQ81+@~P1V@~qrJhbD$ol$;tC_u(T-'
    'zQ6BHO<Qr2)U(B?tXG>Sy&0_w>*j}WK51(Y-4`nK-`Kj8d0Xg%b-vU)|SQA}q4My|7_k(<w)X5S)bZYM}p>yZieP$?a-'
    'L$51G&MNSHZfgSq^f#mPobvMkHyZ}4XidcddgiO}^}c>|OsJQRe@uu2%$9CKY`bly*h{5W8i#d74=7pNK2Oq&C^XjBK(1bAbLuIN'
    'UbaRpbL+k7>V(Ep6-AtcO)eVqX$PJjveBN}HW|M2>6||!r55Jqy6-{MHMhFhNifx@&KGiZ_%A#1JEg4tX=!eG|0*@F=$TP^ZI*-'
    'p=W%)KNX(i$?y00}Y<!lmN(@V{qYW>38FO!z&^xb!(SpnM(-dY8vY^3YGFZLD2#t<?Jimsv2Wq-??<iN)>QrBIu}!2_!8F-'
    '*4{T%O;DvV#wJvUC5dIP5#I6wzZ=uvEx**4v2`XWsIjVs0JYnNKZbFVPcYy_Ju8Z}O5Il<)LR=!EyO$no>DC-'
    'F$4FBK#=xKwGYCKtg?Y6&bZoW8?>F9X9=+LWq^#H1;@$<9ip~4L1nBE!GPfTBocNW?g?5k-'
    'Ld^)Vyr7WJAR^7y>jh)n#pK{=Q8r|V>Kgc<Qb=nHTs~}GOG6~STqenuQIpjouLCkhl%e#PHKq+iWmPI5x0k?yFFDJb{y2Brm)s!z'
    'mMvCyTURs^IN&>p{{$EONuTc`S-!W3PMgmi=a?zGwdLpr4>Ks>u@(E_O3V5SoBF*KAjW##>N<|0s(CLEa|Q#-'
    '$>7;`Lo#pk+bgB8msICcVHD5Y2K^;qBNdGML~=mdUVl!C13VLT3Yn73=P@3@w}9?M_|A1P7w2Kk=K2^STznxyd5J4bZigm39HtCT'
    'Li;TAnqg3D-1KhleVGGOfUL_lExXB(4ds>P9imJqc6t;L;;qg$8E3osP)q`8m@E-'
    'xogi^$x+c`!%Uwen!h0Oa;Mj+0;8bZ?fR`Laa%m0@VUHeA&~_2XV=<nhce=v!ZZx3`l_Q@y6RC9TLb_8NCRFHWm&bB#l(lOF?diZ'
    'I1jw`j7&;^h%kqWHL|*slMKFK8K9~T80D5vj^S5e$DRdEJWCGaEO9OB6Zt^$cKqb7u9ovL=8dL#<k=Tdt$0ZSaFo;9sD(C&|yww_'
    'Q8_3g2-'
    '^ub0CivABO#W(ioBU@5qjcKfZBW4M2ZTH0KJ1K5csUtQ=^+76#=7TSBd!+c(C?|QLLn1nf1Eyh%e1UESvP3D_jtU8sUuqD;7%-'
    '?E7Q)HL8g5Lb2;!j{ow}K0A)OZNs%#1$M#K`GNCL4#m)HNoz%Io321IaRpj!srML9e8XFO&$N-'
    'DpZea3+9<!Zc6ElS@3ijwUQ8eewR<~g0=04VJt8BAYgy@3k6pv~4+v~oz%>x`itfFR4u7ZJ+Jf`Hx(21MrVo3dvIAW&ZUzj^bM1b'
    'uzwL?1j7E|eu`fpaFGI01JtpeA<y5B0zEWZH<g!JU=Nz&44+nVqJL_wH_fz)as$vhLN0KE`7FF%kAh<*cot-pGUE-hqZLJi%HhX)'
    'G~Vp<1g^GI2nyh_%WT}E5C%V>sxc~Wbc)2uNfYEC=z6)SV1W*(;u2qJ*#F4W1ij3TRy7kK@LKbjL0*Nw?IgP+3@_1M_S`sspHsVh'
    'm)=JwhHGhEJ8ApFLeK$EoJifb{05HMOX#KHIcPK{!ssH-XExy|FSfdD@@X@Ng)B^VVCv{W0jcTBV^Ce<Pp<G|@(;RXMR%>RmOG(S'
    '7RDFA1_6r87qYDL=$YZ<gSKMGo4GN%;%j#+AhN(B)HO9YqNV_Dv~G_~=W+!#cn#}RAGFBBE7Ypf4SVaS(LB}q20rP3ECVn}VZ=08'
    '8RwYYi2V<^X8B)8j=EkKIlz>yQ>2G^P@2o^*g38BabGhi-F=P7o;n0Yb%ugl`+o4=2eyU_eFP>8Y)L*67&>utyYi`S-'
    'TLlwF>I6fRaC9QB7l6j>NM-R#%E-x#}jHQh9n<(tZQ6U}Xl6d3I*Z}*4akM5W4h|jJ|4q`<KyMxhTl+2cy5}1{M-NvR#b?-'
    'x77x+}>Uj7;Gf&b<VOa=Rf;ANg51kgg16)S4jlFrOr>GI(;jIVp09Oy<Efwma5QovOS<<{g^urH1Gzy&0X|54R=15JNs@d%6-'
    ')C+OjWeUN>y(+>MfSF<bk%rr^fz@T36F76#9>3Hr?#u<k`SR;4IF?AL0czklE|Z-'
    '8Wbc8N(F@$4YeB6Y?x{Xegi|w9%L(f9lEUgfp%}fuxiwYg^5FnJ|lTBHOMFEl!<_X<z<n`62(inMM!}I6>5)QuB9*$J?Klfqv#U>'
    'fD@=l<=h}e1Zr49!iFaRIJx39anP3O#%B)Al#MOI)nLE^(hQ>rEvyYn$xi7-'
    'U3D8dV9kS)p!lLd_Daqd%aKt3P?Or5&NWE(YFJA}&8H<&oE?gUv7wkFqXltN`|Ps3wE$q1>22#!WYL}ptXc98oz=^U?{T^6%w9%>'
    'Q>-^Y2uIecAV(Yqf+nhp+Fhs%@qE%VFiI#Y3!o`+fjrnBp%WQR4=c0F;s7;KGu@QQtrX0e(*Zq-'
    'Yz|@XL6Ta0RPw5Mr4ipgIERn_d_g+mI2}oW!=9#V#w&G6AH$uNAS?3Iy1HC&YsIoifEzEF-Gq`$&s{*24wvVhgSWqR$xFibWk70J'
    'g>d?l+NV_Qq~$lo1@(!~m7x_PlqowQ6|EH`<Ad;y8Rw%Wgv15m@%a>;G;-@4BBL~LD)HkaCBSdBn8vy{t9FOM3hu?-'
    'ufzl7>SVHAK(yDd@CrNw3D5ig%YkN=dps=>kGQ{quZQYp&yfkWtZ!}kp~TU7w@=|bZ5n`B){2tQJJARP_PyX4E7OgKwHxCNY49q9'
    'rhsw?sobe<)T-'
    '47_u5N=C5vG4YxOH)8v^{msJh7oWBToHrz~dS8A4nj$?b1xk0q&BP1kDw?)^8G46rR=;p?UF`eOQHGdda60SsOaSZdm4wRWZ0dM_'
    'qZPXmp#BG+C$42lK;41t_jBB~8)ZULcK8=326%(6#iszvY*^PGT2@>9ekKqOSL5aH6yHb+iB2f1)6<E5RqUf=7)6)ePHJvkcY7F+'
    '15zXnrq!nZaqC9*USIdt!Mm#_?Ld<%dzaW>mzWY>g85g%zGF4>eR;R=wJ;Ej%24i#G{H#yyA>*=v4Kmuk~?l3EUiwIR_R8@P2@pF'
    'YzB#XI7_gO87|K&9V-8C#*x9TV<s&QN{;4e|+wUR2SSu@vNr<o_V0-F+-'
    'Luy!<ZUI{0(9bERansDSE{WI&TuK#SVL1Xi4Qj3FV<xbTaHY^Idzi~i@u(h@bmCT|dpb6twjcMbh#YQi7y?#Ym1A7My;>?YSiqiY'
    ')byY%+PNYXIOFu0X2|m;K)~dbELSL3e~i+eOKmdenYwZ5Y$p4K5qA{2CXrcX-iSL#l9Rh?x!q}F#)%S|<`p2BJdL<;_}i8?K<^6@'
    '?1?sljn#UoJ%@%YgBYHmJtPU*UEcu1dosDMN$T89DZzmWv?*1>4-'
    '`Ml5pEv~<RG3fG91Ngo`5_d)q!POerd^81^6t~GMbG)X4=h!L!->-FRrV@6x?8Rh;hk{O+$=hJ0cOf-'
    'a1M8eX6;!#XO3KNx~a;N>|_^^;I)W+o%^8$zbiNLvuAt4ui&8xiH39p3bUGg;sjiYCI&EsfM9eA+M{>bOvB0XHpOKl}>to0h~AM?'
    'GVRIbFza>2As<jf#nLryJJ{(LidKu*)2?RDd9(?ETy@aDFL3%R~^e0b43`q6p$}9I#lwBudSg{;5c!P%9&8ogcM;NqLhQo-'
    '4K(KKCqJ&OEgN9^yrrqO0;ijMd~9aL#(jD%}Tk>6RQ(H4bI7TCGtxdUgYZQur&yUp`cF=_AU+*IW?cdF**H$zds;OD;>k@BC$5}g'
    '7moXjGa#MK{Y&NhKTE5n~_JJfJ=)Hqw$2Mh26CMHLas(J|4XHVe>^HX-~8mct-$tzihM=d8xdkhjH$IdZt<H-'
    'hE2SYI5|gwg<{Og*obpJ3hZ{3x*_;*FbyYm^9vvoj@`n48NkUTw>5``SjnW38K)s2yfoA1Cb3Ax3LAah}C#r*@NDK8o<IT4oWD<0'
    '(y4b0;*G`n_7fUT2@*Z3QRz`odadqP<F(~diNCfs1hk9IJ3r|A>x6|w9U>WlkYxA9r9PRRHRioG9zct5DB4WK3SPGdf9l#yT2_DI'
    'f09St)kyP?!)7N^wHB5k%)K>A=_Bz0}~Z$ci+iXfDlKDih_SMofQ_X4J+9T@q}mG&18G1Jumb!ndyW^W&&&kk0t2ELpA~nX_<f>A'
    'ySNYbj0>l@7gR*u&=9?oz|k_PQe@;nO8hsR-ShX(bZJk!_yA}8IH)Yz#)XS#IKbqnn2I5g|Z>6ZLBIB>4`Wd!J7dEi@RI!EQH*B?'
    '`h|om9(@(Zq2z6#$8t9#*}o9t?qRaGuXzfLslc8Kmfaaow`qx-'
    'Y`JDkc<qMK``j}+uji{I2xyfaJ2}o%|_mIK{UZe^O#JiXu<EQm<;txaAb&KE+j!8MJ}}5ilO^bl`}3G05EcT1+kj6DR4q(i7s0Gb'
    'u)Gb$=;drBE_kO2q9?ODfr#f)I5wB+!VHf=XL1xPw2?$$~EO)Su4Q<INDx%(kf14#FdZVQ(U{LR=*S1PrRk*l?T%$%7F+`dbtsQq'
    'dc9--j9vzBObYS>PauYIHqNMQW}&n3uTf6F$-1?){&Js{gu-i<CF`q)8qI|TF_-S#5?6Tu5!dLUd!N6QlQ-Wl8n?S>iJD<?JV6OT'
    'YTI%AKpKq0i9?J^i5kNr7Bs$1B9x|2e~-K+84fYw8Z9;dRZQ!#GENS-'
    '^wRc^{VSXke6c^rFyDX8U8~Q7Jt4+pSP8gOq}JG0sbrv^|@#x_%zM}hgLd|U2!ui=tX=r4j#`~v0Dxf3#yfm=Cmhbt#W(`bGa4(K'
    '_q2HxSF#ZbFs>YeSzbvrwbZP<#9ylarWPhvxh|IKX}W>5xE|jha32SNV<hfO9<21MwxBAfB_RSA1<Zm#(`nUz=7jf7~oP{T$H;RC'
    'q)%ub0j(=(`|3`MED5Xf*xX6P-'
    'hckjCy|O3B8*AW16C0^qkh)jy2<3_@?t6fc2=2MbscppFw%uB7TE>h*Q4o?<%0M5FAV6u4i2x@@xhJZc&n$>8DT*U_uN?%;6e;sM'
    'Kn?^$jkeb4~(NxBx%pkr{q{{u+lmO~HdX%pN7jW8=ZYK0t!988z3S#3P9P*60Bq=ux-UfIWLf?~qFQ%(Bw}LinsVp0SV{jXJ*cR7'
    '%`62<tS^o8X`{4!Uq=b%zJr&@}h-'
    'vT0=EuLYLwlWdu)0B|F?MqVsrN*D|n!{?lhJ7vrG5TMJtLFhtl15NX_C_PDuBj3`#w5s@4KNUzuTSsfrMY+76_6;{`ANU2LoTaVR'
    'Q+^=M6x<}q-9SoCccL=|I9zIX5f!v$y!9bl3dUe#vXd75Ztl|L^cO1?_rwewYK0-'
    'DDatm{>5+<2Can3K>*JXr+D!^<bD5@)<jq*uf=r3FsRg9jF~AT_bUs53Q1dlb)IUgv2CBVgh#Y!5pur*KmUMM_nc0Yxu5<{~zg80'
    'opJh>y2(I!jb_N3`10!|?REDYOaCM)q^kZEhnbRd)S4oprAqQMO&C`Q=orI#c!DL>C?2{@0AmTI`9xP+88L`Q2z=oWk(hRC8=SZt'
    '#nD4#qhz+(6D9(uyi6Ys=79^rKL657^CIP!ftSwC34J<eh-'
    'S!J5A0g_)g%#UqoAS(dJSP6EtXL87VGo?&50}@m=2wN|_VKbz%8DMcuMiD{ru-nRdN@0U*;v?(7rhRQCU=ngY5U^g!Yh0~tCrE=8'
    'W0#NOJWC*gk><j-n6rHT0t;77}E{eWKwul4MquUG+?kSls;;Ik~)DUU^D|9AtuWLf~a5%c8S0gy95jsVhXu%$!2-'
    'z=H3=tM4bYq$FAkW>s!GDKEbu6lF-fn*YU`5r7P5G^V0ijJNiu@iHqTzp<>Fi|7_k&lPp_yM!4xif@=Y-xJu&mxxO#u-l!ygN-'
    't?UbNjUH4X7~&)g~W)0y{c$bnsf)H+z^Whsw@1>@?_b)A90@M~tkyLWb5uMVgk_QM|-raFvM|1ZFhZ-'
    'e78J25*94e8@5ds)1Je_A%e~fQToBo*Cw@Rkyb7Q`2l<Azzio#k$a0Mrt?YH0BD738Yyp;mXlTcV9jQEE{*H0<nQyPl3QJr6txL?'
    'JsbGpBE(>aa1q#zhI;F6Yxkee;OMa?Z_82+P)0nj_v-'
    'N*S3hjmmi<u<LCeTpZ@mOAOGzy|NZ~`_0J#w2z#d3860dHcT$(&+57P|=I)>52j6`2_7879L5aWH@4p53#tEc3{Qx^$3)Bh!gVH%'
    'z{Dt5A@b=x;KYpCe?|+b`OE%DFrJAP)UW(X!q8B|)ZWpYJOvC5T8*5{)mC-tnLMFKLOk|>m$ljUkU}<_&I%sX0D`wwhdgI$N`lrb'
    'BHXe>RM|EnE9sVf-;|mCNL<pFBl5w*)Udk_a3&|3AyqTBEZ_UfWxC#<A-'
    'L)c%*_1uwvw8EIN0}=ao=t1JZjB6_bd8}g{ff_So_a$gH?Lv%&<ra|WxIGXCyHkSbC*(aiwAD_7<sS&f^7T{F#6GfH5fzjLt-'
    'Z7C&x~L6a3TSF(-'
    'S;w@Moq{e5_dZ;Z^8G!MkTQ%gWd`;R$=+r<=82|to{FO?orrKpld;I6z*{1N*fGVU$uhoz;Y&%3<~`7XJXW;(j(HLT8-'
    'qkPNCu)XW4lQ^{AMQ0K_S@o14=y(8KZ12l+Y4PpW9QHy5yJ%9uCTLO@it5d)zK#g6TYk)NIi8vw$>>HzRgcp2+v`OjrI^ACY2f)*'
    'xpn8<VFMA^?ifCV$Jjo8o>y@p+_A1{xes18$DSxc+qtyNySQ<|5PsG0ObzRq<f;Y5t2m|f4BFq^=>8pEW5hPCt7%q2uNk_!)c@*+'
    '0}I}7@7iU9Ne|$ad&7{cI%}s^&*GH8XWg-j?&<02V9%It(ha-'
    ')Ov8a&UCgKA?pN;*)}4I%%g?`1N@V!u%!TAXmwTGDSvC{F%GK!UIZwjFZ*oz$=4x3JgDkgd2K}il_R}(U1X~b6qGLVhS5xgi;X-'
    'pFmnY4j(^|J<3n&2t6O6^tdVlAQuqbWbuIZRE(&)CfS7=hvsYAu!1f2`|bLcY``iYOf1UEt9b9|+j+~+44zV=$Wk{o+G0)?;4oU~'
    'tWFcI`s^CI`d0s5_5<n+x)D&_m#hhi+ATfLe2Ptn2ig@VR@Ok>9Az!*}FsnrDHwV(dLEck*NWH|SFy?<EAegyf@%SkAOJ*Q8i4ql'
    'Z>HDMRRY;Q3rXa{;efMzc`8GXTSu)Z*w>iJ8s$GP>0L8GUGuX%MX;0At&H4+$HkX;`>S$Q0pByuW*X2l`E8A;y#?8i5h3U2u1LxA'
    'B7sl#-K^{AYQXKPoy@Rq^tm}#9CLmkE>)ZDOXJXB-i)`yNnrz@i{Xth;0LxitzhzetgCzo{0;Ho&HX-{oV_p+C5CZ`11Mz3YZKH-'
    'Nhnzrs~g6-kx+7Ef12--xOBVSQ^ZI15x?X5Q%_7ll1v|d%`&7xN+M}u)fvorTBDI4dhYhFWQS}V@ty@H$LU_WLoU%%1|&5C^&(#T'
    'CPFXlkVbn~i!w39op>(7I;TBjj67S}pFA~*mJU4l+{`WQ8glRYuzEv!QQrL;a+e?K<zI2UI4SwZJF@1a;cC0DI`TFSMVX1+cWhB='
    'S7(YcU&)+Jgcg}C<9e%&gJJKR6zh=18{yixteo5V(-?i-KN&7_;Gly-R_yWG_5>}4)5W7Q)Zsi1FGf@7-'
    '_oB5O#5xeVpFK$5`67?)40z`bG!pvexAh?6ulSkJ_^o*_$8oYIoyqV))?)2`Hg&_ZMS`Y1&RpzICaal$0L3t{ewEG;^?}Sane?*C'
    'Scisx=*<N161vM}4QLRRARl%tErKC$=*AVJw20QdrR5ZBw8GyrzBmFfBn4{o8FU}wnd+?$=!>xuWnFI#uqG7WH5kJRj>q`81Pud+'
    '?$Z;Zd^EwMXiwp*6tdqv0cV7FQY;P<&HWB>S{sZwcVb-'
    '=CcXSb7ihmw+W(OA<_|~LgSKej5ru>j@k?S5ZMplIm2yyKUx~4h?Dm6}ALpjzEG4?g)De(uv7CF{ZgEBxi3BFac<{=)D(35GLtr4'
    'F~dWNWNIoJj4P%3H;R|tpNb9|2)(l*ct?)Z}Wmp1))Bifw$Bo)_2Sa`}EWwAnQw~hEnslq?<$1OPA=ar4XwbU^Zkg7@r-'
    '}sUv^#x>k`#Kl66X$+8(**JcaqKR;Ti_4EH))y<cq)$URPd@%hbdRE2ZFAAFULx7MQ%|r2MkFq*vb?{+=XABPlXu55a|^sFZouZF'
    '$uCMc?LkYsR?DzMvIxlgT*uGBqv_5eYy5hF2-!7fvYrl*w-'
    'V97_(fsF$tqR6iRjavKWX7yrFXMg&AoQwB^3wpgj0?C_R>TK7hcrP#hPFH=OWH&J|3HsAGl0Dd4nD_{B@sk&IVDMV1B82#p2MXkE'
    '82s)?#M1#%H$1zzPYMRC)8YC#s=k)Kz>wm?F*=tA4a#yGJ-'
    '1Ze$ks2VzdU!58_?)0hKT0RGe$U{0oR9T=+>{I58@c4nFUq=Q?KYcRe@W;s0GlDx^)^}-'
    'XK+4n4W~o=5_QE#0S?0BqH304aZ}<vi6#Xr(v}|fJ9^BClP+ltJ`d$QKQ5)+_nH47lb{IT4J3{1xIAQCFJPui|)d)E_T%<vNXIk;'
    '>5Yt}9fAnlJ{d5=LWNg16Gz~brR&w!_V*p&ZL47TH(-P-'
    'tvOUh`F;6BZ_mAD?3>*v1Gk`|Z+;|?s0XoMEiU4bRuyuQuNg<h+8o`fA=7_3!Fypmsk^!g?6K1fvQ8MIpfZx2l3?|t)UuE}rt1pW'
    'nXS|OoVjFH#`)ZOPFDz`UY9hsW2t~AGSbs`5)%(iJuXD!Mi3s*CYPRTO5w3ZYtldciDfl7K=}jp);z(j7!aO)(<6>~Y$VeR{8t|9'
    'Yf{ozH<Z%<?E_#<KZ+?rH2%*`Hc~TueHzI@)Kmfl+iutAKV^*)E_UZx-xs(CB;5kBO*K%JNFz`u-r*DRKoOFW4?-'
    '}Xtoyud1n%3*Ja4y_sh9s;*5}fG_KVbg`BE3#q599e#G|>bdSxLOZG$IFijD}GVoM&{X3OS-'
    '&<(m%|0%gt3v{Jf?eWR3d@G{EUbXwpSC?%VyU61ylctjW7NYC#iSz*`zZt7Kym4U~hFP619u-'
    'HJ94o(UT4>GVL<Y&mH$zfQ~H2|Zr@CU&{gmXptuEs7RbN~v4QKx%=rj0pOB6x1^QV_>}$KtK?P2U(GC<fD?YPaz?#N4w#C^+gFJ0'
    'q^rF}?;?NMdYWnUf<ZIt3SuMR1%eo<Bxnllv+SD6G<S$6h~pvl)jWaa&D}j=cqgHIWa{AgNeBU;)W>1MU%jksQay$#;y1Qh*W@D5'
    'A+akAOxhACpY2CF?iLreTtWaRl)hg7sE*o|=Xb;Q`p6q-2hiGO;opusqh3uOIy~ID@_ocDAm@&O{-'
    'gAzXR|>Q(W@qYu^dJcajHS+d98!Uc9PCS5!~Az8*}9S2b5Ewa|c0K*x2j&lgjxMXiG#RG+O1W)pqQeGu%Wguvi6;C<Jews@5hwg#'
    'fr+QV$Xdw@;d!;OZDPT$l#Y1l4%prSvV@!&U8#;BJ=suna1xSK~pe<cTuZxF(g~XzCm4~an)``fS5p*La>@_B>Zl7q@SUB)CO_9C'
    'S4egz}0DY<@G!fdDy8#GvBBa~O;hOjirFenySx3waP@VPLdGkiB>iXV#EZH8IxV~q-'
    'Z5je2glpJ37Et|)N5fQ*!eU^TNchBZTr7))Y<+G0$eee44(%=i%5FaY0R+0ijEd!<B_;QB+5YXj-'
    '(M@OUi2!JG<jYd;`iv8;wxZ@d+Q;u>&>G!PS=Y6pJ`T}r|OKjWR<VYm9p_2QLQ8$gfq<tn3sS%+N#Aeuq%eo$4D8+bDX9-'
    'nYF=l9k#*jQnN`Nz0fg0OduT{{BfwkUO=RMCbz$;7C&9GXIwR4mvcF@F=NA0Q;ARG?)2+}1>>tgQg+f1+)~WMJ*~{y$O>cO6OEf8'
    'Ch+NfUH7oxc}-'
    'oBoYKr<FDc%*lby<gdFE*(4!C>t;gl>xMuD(3R;nsf3Qo3<H;}fVQH;L|)%IXwTdJJLH2LMgm=;*Xqhg>>+UFXM6fo>nJs4~vAa%'
    'e?Hwp`lXN#1~LeiqFirj%N*zqG(VsW}(Nc?p^xgMCFC44c(_}A8S{mgU5W+gWglo!N%m0oX>-12q0tL`(-'
    'c($f%xo5S*e5lejr4Gy<V)(-8SA<0d=uew)-'
    'SrB+yuGkMO|{YTW|nGs?TxNG)4C0;C&yHIV7bMVl}bOj)uY3JVr~3_CV~?tsQ|^4zD?hCj3O5N`Tc+iFl<o4?0jA%91^TMrcD=!I'
    'OBlRb(VJqO*T5*NMeCGcWGsqRt*d{4SF#s?>>hCQJ{x80WH!<QDtGelv}iy2EbV+NL+O8T-'
    '6kP9!!pPQZ$wP8|X+Ka9F8hp;o6=v3}XN6;WU*ko&Smi;BpT&3d449PfliW`J3Pa>F%pJ1Y}c1Ub@o&j`g6*biP`4?v!zk82>O`!'
    'oV}^Q!?M3X{*$zFi8x{pF?bQ5H1B5ePX+6My(GyGO5LeicS+lMTBwlYDCb^ZXkRgS>Er*0S`1{$}z9Zd{^9L*mvU4VCl}-'
    'uPiJf`6X!<~04EjXqAUIFvpOYq3Md7;I`q(J4z5T9aGnmdi*xT^f7GWO$OVkW+_Fw%PUgum2C66c;}*u!y1AlAF?Yzq&aqAijI0;'
    'qLV8%-CdXBY`~IKlU7VrD>ba*VAN6zsAxgn~t^bA{7CyWyn4we#e>j=1l^0?>SURFB<-'
    '<t+wA_%pStVYv63XNx92>qh2q660J}!VxeM*<$ANHw6-u=Ix-eZ&U%Hp5tc<R7rpVfGA(^^kS3)VQ%uh0TktZ4Asai!8g*&>j5n3'
    '9o5`a^4&H{cv*)3E%fUG%AJDupNt(+recIwc1>9Q^JE1Kp%eIBmoqzh}EJ&%v0<=BGh#z9(y`B30^19^j>@NAO%E`c*mGF&3VAfv'
    '*2*&UK_|ipO*6Zm^3py{v|Hi|vwj5NRhREO=wD)Xzq3H!$3TnQ<UWs%nv14D3IYq`O$9OBc2TQkHY;UM(fyP#9En{7{EWNFi$RWH'
    '4_L%6>CJ{XT1(mSO*nPmQ+S7PI2s4w{llY8Xh)n1-'
    'USEC&ie+G*T*b7Q@2gsr%jX>3HH1`8bxTU?x9tll#XKFgG0sKAQ6Tm^+AtvZLD!w#XQOU#kP}x7!ad!XBIib;0iCuK*@ewJ&OMr6'
    'r)LiscQbW;OXLXnS66GnYwb-'
    '>qE0)gYjNOxIS{daJvh}o?iTcbDIF}Je;<R2ybe&Z?~%hNlE^8nxYZ?BD$rtJM3NJe+32kw8@{op_d#WhfR7aC^~uTiiLVzQie83'
    '@`Wa4Rij{z@+W>CCxptmwUtAS{H92VDX`B2yl?xq>gd&I_mG_h1!h82}L;%Ox7&uM_yFchz?W!^m44x*F3gUV(evHZNxkc4rg1m#'
    '<X;6SU=BPjLESC8t`t#f1O)CvDLgEn@NvGcJH~;hOj%gm|o}*KBCBU$V8A1AU2~(;gJ^}GVvxO)wRP<vI2D@o9kK;cm7zLe`%Ql+'
    'ds-V$96gUgw&0xnuyuJ#}NEGLqx5ogkWfJ*B4mAOQfNV1+24sa0WC<6A6vaNm$zyG>@Ji|IsYBCmmP|6$_5o*yiE>w3fq-RS9%X}'
    'up#2RcG|06Oht0YYB5G05;i>lmkzvN}4c0qB&+K}d%cMb=WdZIa${zr1OvClSl-x+2*0y-'
    'e@p0IUJK{C5RpN;3)O#?uYVKk4R=zcfze4z>3Y*VR6at!&^bOe^PtJzcMpa~a{Tw(+oWDL!vXil<!aQ8}ge%NrM=_6u7ev-'
    'Sv~x);o0=DA1cN=m!|}e5*X4EsKmxz%x?@;OMPGY_w-UvBTGR2}2brgj;xO(4z7B3OgO!k`b5p#y_pVK*>KfQvf&EBZ22m9C>--'
    'jU)+=_#FGNmenSPe^Oh}tW{DSul3h0A3k<D+XaLiO_J?dO}dHY+rVw(t$3PQX~z|ihUzWVfNO=pfsFTj|dS@eUM@?6Ib=7-'
    '^V<{I-'
    'm)xjg%NwlPz^%C~BAH00ky7iZ{+i57&O6u9DtuVz;J$l)AR=7RziU5EmnPgAzX$rE&oH#L4l(zGvID83B0V+Rk_oyNARBz#>+(qM'
    '3GnXba7hbLco4EK;IwW|{kf1iI^<o)>1}@_^nfJ)Tpl&AxC)_yc>Qqbm8##$F>3F3s901c~fU8$eHk(Uc`<4;^prCjZl(K+Jp^<2'
    '_vB8*J2Klb6<?{MPi7KTQtb9%@yq~1g_f{mAs(Rhaw;rXf0wq6@<}*yPKB4+BN*1QY+8N}+(0#(5A$yvaBE}3*y0ki?7tV3)l4z#'
    'm07uWQ^Fn6fn6W|{gUM{4k_D747P-!SIT^8S72Yb^ZS-4e;zg?8jzWc30Kzk-m0|^1meoT#53a4T*Bs-'
    ')Tx<$P<(>qi&1GI@84cV4H`9Hx;4QE=s9LNq4>HcwVV!X>QM1+$+}h3xV!c?y?Z2W#z)EjZU{w=kLTw#hQ;|dc>_Dv!%hSgn1aMu'
    'z&v1m`a(oo^l+_a13t6Q6QyRG%p7xF$4lUmJ&*9ONfKUtl`wZ#H)uRbwveC4v$WKwtLniIdYk(T%!)V7_q+tbME9Ocs+N7-'
    ')l4R$f8z5y!7a53Dj&MkOpbcTF(BH|+pBj<+f~pH2_tHF|2{=R;dSjMv?T~zppH2%8EqOGU`Se842#)yTqQ6epsSt?WQ!ox0aeEj'
    'L%X<AU-ANu*u95e<Ztc)hUQUR@GCv5JNohF40&2m^8d%~yHU+?o>{Yp<^h(*(Qos~bOJ@EkCt7ifJOqxJk4AJhEnV9f8#5)J$r0)'
    'F0($zREJ~WPlp)+rY8C8Ja8fp*)($TWs{GCK1ta|()J)-'
    ';vlUhz;1_{;Zt@Bh)S(<e8qlY&tvkdS@=d7)%x|f{rrV<lP0<<&{VAo+MEPb_V#7{cIgq_W^>?zJ5#PenW@+%+A%B3?M`+)%Y_Tw'
    'w{W4El*P0*nNh5d;3_XE~dlb37;T6lQBNZHkpawzRs9-@p76;Z4<u;M2zGf6(FW^c~S9EozvOA`PZUm=rswW%O{-'
    'J_n5{=lMQ6ax%XVL|lQ(_D4<~u)e6^jy-^RswDB_soOYtjxi#>8EU8C{7MU3K<7<b8Y-'
    'O{RLCD;^#&PKR<Up5hI9d^Ymct!$?%tX@@%o5N9<SD8KR9b>qT(^t`o3S9DBTE0$JxEU$IR59WDqzS|~kw`?Kq!=<Cmh>B2$#=BB'
    'OzuZ|`WJa2liDMjy+x83s!3{-e8j=tG@4!UoQe)#CM|SRY$KMvEEQ*Ukn^s!Ho6B6#HxIA>;|<Im1^TOQ4J{5;i*asaicl-hD@N('
    '+8Pz|7++*nRel!@;Hu9+orvi?80CT)j#C}2Sa6KnI7h+Po;Zdx1_ztxur=eFaNvoj{PHeILhdv=W<45x2k;+rL1=9+-'
    'lpOZE|K+4tira>8;TfFkt?)S3eO-'
    '^Rs{*DOXU((BC>J!t0oiy5jYCuIepcd4Rp!<`NRI*`)?NbL%$o5V@}%+aftSro1K>hA>tw<2sbwnYpC1mBy$cBxLt)y6bwu!F@Cg'
    '2qbh=W8cQ{+U7G-88ClW=fakPVv^lulQ6}C;G&`q|9(X9vRk9r@t;f`%uFBdejV5ekNyPA8VNDUV!K<_k1)5^^P8uz^^U-'
    '9IvYSUc6!1Jo;hn_S6R42-I7remONL1fU{s9o*@nVjb)cJoC-Yb408f6;H&iMF6N_+C=c-'
    '=w7GJCBMSJB<=~gSymOR2<jcCf#ycmR1#W9zl;SqnR50OKBqhs~NttHs*jke(+R&~71&OApuxM;U-'
    '$PFRVNKVgTHB)vRM`4o7v~Bx1&{D@x3=^ZNzJ)aXPZQGtqEAhk93skj7W#L>iK${1#fF_t>t8hJ5qHY#)cws9NCxKKn-'
    ';6agg8pHlZgzOye}X8K*8neW&$}D&M|8?8#*|;bvh;xvfb$xx;G`4NKa89QT~{xep9Lpn8D=?f(O%wp#Tj%397ANruoyM2FavaK;'
    '^)E*!ZaeiImB0LwighSe8jS*HE3}^Tf6>Sh~r%#7G-+b6$iLP&I;5Eq#K=lWMCqjkAVn6t>X5+&F&9-'
    'T@Knc2BBI!CS$q0Mn4glf~@tTi2|7G1E;fUsx2B0h3qID<K14hrs>I$6;G2PfOX>lX1>ACaI#*asLcCNUa;vg|ba$N}C2zsu#|Yw'
    'y|WNBv5i^7(zt^z|+@(`c7%q%PlFoIG|vDF!g2{RGfYaUG((0S@l4|-'
    'LI%!XxG3p)?IxVQ}}z?dGb1GJlWj4twihlX}v^N(?&e83#}&Y?jW6gnUXL5U`HByGTBg3s#?@5iwzkaxm1u?9tR=yjY+P53!&7K;'
    'Q-'
    '2>s?xL<bJ2;L6=zRt(Nysf+{P_@b({#A7T%>+?r{<sFy$wHjU+V!D+#V=vAbJh2R^dmSHjuQOrH03^H0|>D&kgb36JEjYBASacwE'
    'OQaI_sK&+2#>?bb1sRaAoF2pAWZb)~wgNC#G$?j``^*X2b+mb)PplF8(l{F{dL=y*b)Je_hDO)ukyB^bB?J+iTf=#h-'
    'u@hNV~wyOYyca<3!p3J|a(j)~HNT-N6x=Fqc+Y$0xN~YplmA`HUl}HsMXfc?4;U#@h&jVzBj}-}Tw%@aBK7-L1NL0FWp)LymJS-'
    '+0`J&L`#mP_*Impbo(a!?q8UW(J=}(jH#-'
    '{%4+jVAoeQ#~wq?CWhkeOYwKkw{TonfDDT6=c&UOI*Sjt#fn72a^&wsXE%HBnP%nsQG`?H~eErtj2Bk%N9q;_r)>-'
    'tc_(eOihE_KnHk?3(hhCjBlseZ<o(p_FL%h)kM8efefbs^m~nJh~ocM9Ga7gx<d3ffrG>sb<w921ceA&25NQ%(ainLg*i_9m=j<n'
    '6pWX8+YOr!ITN?c86ikM;06B6#-L5U=H=ew3wy>)w3n0m;#UYEy7VF8v}-'
    '>4^cTHmB71y>{e_%dn4+BT38Qp6$8chn2VWRTO&nI$uyav3=s}anm-'
    'm7Z%KNCu^q@XdV~dlhTKke12ot;jH!QUW=zn`c>c5p?39x!V|Xg8AGhd-_h!dPQ4@nT_IZ7bpSeoLEgDK(;S6w~o6#EOV%@+xr=S'
    'QR=3TIBCu(ZgQX5qCUHUmB9G5`{9lFS|P<t+Xc?_qX&xy%I9O;}J5`Z{oV1(0P2FFYX{e6)$fM2N^tZ+@|mdv(ik1q0qP{qZSNne'
    'g)p7qWpi)$H;AIGyK=)grqe(1J#JfN{8XB2t+LO<xRQ;(>H(qVcVIp)#FPaE{^nXYR??~5TdTe<wbaLnBDEN-'
    '1{&qI;AxGl*o&8m&V{ya9fwR&SE<gal@*LayR<x!9SM>r1YO<4kIlDyry&)Cy(%sM_+$5gs!(8ESek}Wdif{pax?Ryq_%GE8r`A!'
    'ux2>!6qs<5!Y0M6?u(*cwHIQtlhChvqiRk1nB=JnOoNVqsw^Mz%6Ak*sVSM2Rm5VG(EZq{gP5NTzr{pRil?Khm;L1`f!Kg5nj4~a'
    'm0wM{+PktQ6(&*tpum}f6&xi<{`97{f0Ff*DtE$;YiTaS7#01wCaFXgL4wwEns69TMxjyhT@*z^XjP!nbu=~#F<wWQJWImJ20Obv'
    '~e{K@-'
    '@^TyEG=k3au*jZg62Io5@P@CqM<GX;lUpZ9%+xg@iJj+?`9i&tRZefpOw!m>L<%ae+V0vsrB@zVQ+6#vZ_ppUQ7(f$IZ`U@gC^>e'
    'htFAs^Gte%z<`!-'
    '`9EWw}^Zkw7bkbpe+yQ$!H7(NzhZc^_Xi(Ni+P*jO3rjpD$F^_ocXQ5eB3%en{6W`Hl|uA7Y|$^n7QK=uP3%&BRWu%#wBwn4Xd2H'
    'tnRByCD26P0IO0lRHid(P8#<Etra4388mfos%Jx;r#tl;%Zj(b}x@q3LDwZzLd{oZRHP5kpX>9HeFWMG@y1FY3Sd;RFi#hEztjF3'
    'ob93_inyRiobzd4aSHc~HWJ}|2G`g9qrol0}c}4KpX>XTVu&?cD&zFV)Y?Q~4HnKN63bCBABO!QGDbN}^MFB`AT{+dQ%j_3%&zv6'
    'I+p(1KOyC40QmGMD?PR<{8q-*yQz(;=GAiJZwy3;<Yu{F=atU`CeKX<gumfute0-__v+|@ySYHnp);P4jV-'
    '$?)R0rUZWBw!fv4%x1BAHN1iNmFdKVv9wUS*`MwkTIU;zCIIg>V3$7U|{p%rT2Uutm05Klb^;Bye;*M%W{5XFd||-'
    'S>?wdv9m^l5eMH_#k40;zJf6iH6ytV&im@-'
    'e}mBYP?sgE@aOWpQEJ#3nLgFlpk*S5O(dxRJeHY)zrC2v@8ra?sXrfI&hDo!CUW`d|+{ezDHh(u#s|8Za%Fdqwq;9FFd{6t+m#c+'
    'a9j)u4!m$QKU{*wrm3r?!J-P0nsz0G*HG9Q6?TdMe`c`hbNGfY1R0bYjbqsNT-C9`1hviG9@^5-1o1im`uh;0P-'
    'H>Ro6rS*&{5$k*D#X8b0YYIP7J*&c=EN#_C4{Tm1~68zg_2EN^E|u(=11u%qSss}-}J^9=F}*U;m%V(uv6V7cla|MUL?0IG8G'
)
)).decode("utf-8"))

from v23.state_encoder import get as _v43_get
from v43.sparse_router import SparseShopRouterConfig as _V43Config
from v43.sparse_router import build_sparse_shop_router as _v43_build

_V43_CONFIG = _V43Config(**{'yarn_first_start': 88, 'yarn_second_start': 153, 'bakery_market_maker': False, 'egg_batch': 10, 'egg_cash_reserve': 2500.0, 'shed_headroom': 15})
_V43_POLICY = _v43_build(_V43_ROUTES, _V43_CONFIG)


def agent(obs, configuration=None):
    try:
        return _V43_POLICY(obs, configuration)
    except Exception:
        seat = 1 if int(_v43_get(obs, "player", 0) or 0) == 1 else 0
        farms = list(_v43_get(obs, "farms", []) or [])
        farm = farms[seat] if seat < len(farms) else {}
        return {
            "farmer": ["PASS"],
            "hands": [["PASS"] for _ in (_v43_get(farm, "hands", []) or [])],
            "market": [],
        }


def _kaggle_submission_entrypoint(obs, configuration=None):
    return agent(obs, configuration)


# ======================================================================
# knob-sweep candidate: v32's close-game layer, knobs parametrised.
#
# Chassis above this banner is agents/public/kaito_v43.py, byte-identical
# (63,309 bytes).  Nothing above this line is modified.
#
# WHY.  A v43-vs-v43 mirror is an exact coin tie on 10 of the 16 wide-panel
# seeds and is inside 92 coins on 3 more (measured, not assumed).  Under
# win/loss/tie scoring that is the whole flippable population: any strictly
# positive edge converts a tie into a win.  v31 already converts them with a
# one-step, 12-unit pull-forward of the next turn's scripted premium SELL.
# This layer is the same idea with three knobs opened up:
#
#   _CG_HORIZON      how many future tape turns we may borrow from (v31 = 1)
#   _CG_MAX_BATCH    units per item per turn                       (v31 = 12)
#   _CG_CLONE_MAX    clone-shape gate threshold                    (v31 = 6)
#   _CG_CONSOLIDATE  merge same-item SELL slots into one, front-loaded
#   _CG_SWEEP        terminal shed sweep on the last actionable turn
#
# Measured settings.  HORIZON 2 / MAX_BATCH 40 beat v31 46-2-0 over 48 games;
# HORIZON 3 and 8 were worse (they strand harvested stock behind a cancelled
# scripted SELL and regressed seeds 7013 and 13049).  CONSOLIDATE and SWEEP
# each measured neutral-to-negative on top of that and are left off, so the
# shipped layer is exactly three constants away from v31.  CLONE_MAX is
# tightened 6 -> 3 because at 6 the gate false-fires against readmarket and
# perturbs 9 of 16 games by up to 76 coins; at 3 the candidate is byte-for-
# byte identical to the stock chassis against both non-clone opponents tested
# while keeping the same win/loss record against clones (LESSONS #15).
#
# Quantity is conserved by a per-item debt ledger: every unit pulled forward
# is cancelled out of a later scripted SELL of the same item before any new
# borrowing happens, so this is never sell-pacing (LESSONS #11) and never
# sells extra (LESSONS #12).  We only ever borrow stock that
# v19_terminal.projected_shed says is physically in the shed this turn.
#
# NEUTRALITY.  Every item has its own market inventory, so reordering or
# merging our own SELL slots cannot change our own realised prices - it only
# changes which rungs of a shared ladder we take when the opponent sells the
# SAME item at an overlapping slot index.  The pull-forward and the
# consolidation are therefore inert against an opponent that is not running
# our tape, and both are additionally gated on clone shape.
# ======================================================================

from v19_terminal import clone_distance as _cg_clone_distance
from v19_terminal import projected_shed as _cg_projected_shed
from v43.sparse_router import selected_route as _cg_selected_route
from scripts.v22_market_impact import impact_score as _cg_impact

import os as _cg_os


def _cg_knob(name, default):
    try:
        return int(_cg_os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


# KNOB SWEEP RESULT (2026-08-29).  v32 shipped HORIZON 2 / BATCH 40 / CLONE_MAX 3.
# Swept HORIZON in {2,3,4,5} x CLONE_MAX in {3,4,6} at BATCH 40, plus BATCH 12 at
# the winner, over 2,304 games on the 16-seed wide panel, both seats.
#
#   vs submissions/v32-55799530/main.py (wide, 16 seeds x 2 seats):
#     h2/c3 (= v32 itself)  5-5-22  half-score 0.500   <- sanity check
#     h2/c4  5-5-22 0.500 | h2/c6  5-5-22 0.500
#     h3/c3 22-10-0 0.688 | h3/c4 23-9-0 0.719 | h3/c6 25-7-0 0.781
#     h4/c3 21-11-0 0.656 | h4/c4 22-10-0 0.688 | h4/c6 25-7-0 0.781
#     h5/c4 21-11-0 0.656                        h3/c4 at BATCH 12: 22-10-0 0.688
#   => HORIZON peaks at 3 (2 -> 3 -> 4 -> 5 = 0.500 -> 0.719 -> 0.688 -> 0.656),
#      BATCH 40 >= 12, and CLONE_MAX rises monotonically with looseness.
#
# CLONE_MAX is held at 4, NOT 6, even though 6 scores higher.  On 192 paired
# non-clone games (readmarket, rayk_c94, tetsu, frontier_soil, salem3000,
# boatlee_v20 x 16 seeds x 2 seats) CLONE_MAX 3 and 4 are byte-for-byte stock
# kaito_v43 -- 0 games differing, max |coin delta| 0.  CLONE_MAX 6 false-fires
# on 17/32 readmarket games, 12/32 tetsu and 2/32 boatlee_v20 (deltas up to 88
# coins).  That is exactly the loose-gate failure that killed v30 (LESSONS #15),
# so 6 is refused.  4 is free: same perfect neutrality as 3, better mirror play.
#
# Quantity conservation was verified with telemetry on all 2,304 games:
# borrowed units == repaid units in every aggregate and residual debt was 0
# units in 0 games, so the deeper horizon does not strand debt behind a route
# branch that never executes.
#
# The env overrides exist only so the sweep can vary one constant at a time
# inside a single byte-identical file.  A live submission never sets them.
# SHIPPED AS v33: HORIZON 3 / BATCH 40 / CLONE_MAX 3, constants literal (no env
# indirection in a live submission).
#
# CLONE_MAX is 3, not the sweep's promoted 4.  The sweep found c4 marginally
# better vs v32 (23-9 = 0.719 vs c3's 22-10 = 0.688) -- one game in 32, i.e.
# noise -- and found c3 and c4 equally neutral on 192 paired OFFLINE non-clone
# games.  But replaying v32's 160 REAL live episodes through the gate, c4 opens
# against a validated non-clone in 6.9% of games versus c3's 4.4%, and HORIZON 3
# amplifies the cost of a false fire about 21x (-15,470 coins vs HORIZON 2's
# -748 on rayk_c94 seed 5000 with the gate forced open).  Pairing a deeper
# horizon with a looser gate is the one combination that compounds the v30
# failure mode, so the horizon gain is taken and the gate loosening is refused.
_CG_CLONE_MAX = 3
_CG_START = 160
_CG_STOP = 700
_CG_MAX_ORDERS = 10
_CG_HORIZON = 3
_CG_MAX_BATCH = 40
_CG_MIN_QTY = 2
_CG_CONSOLIDATE = 0
_CG_SWEEP = 0
_CG_SWEEP_STEP = 718
_CG_PREMIUM = ("STRAWBERRY", "MELON", "MILK", "WOOL", "EGG")

_CG_STATE = {0: {"debt": {}, "last": -1}, 1: {"debt": {}, "last": -1}}
_CG_TEL = {"borrows": 0, "units": 0, "repaid": 0, "gated_out": 0,
           "consolidated": 0, "swept": 0, "sweep_units": 0,
           "fired_steps": 0, "gate_open_steps": 0}


def _cg_telemetry():
    """Conservation report: (borrowed_units, repaid_units, residual_debt)."""
    residual = {}
    for seat in (0, 1):
        for item, qty in (_CG_STATE[seat]["debt"] or {}).items():
            if qty:
                residual[(seat, item)] = qty
    return dict(_CG_TEL), residual


def _cg_is_sell(order):
    return (isinstance(order, (list, tuple)) and len(order) >= 3
            and order[0] == "SELL")


def _cg_qty(order):
    try:
        return max(0, int(order[2] or 0))
    except (TypeError, ValueError):
        return 0


def _cg_repay(market, debt):
    """Cancel pulled-forward units out of this turn's scripted SELLs."""
    out = []
    for order in market:
        if _cg_is_sell(order) and debt.get(order[1], 0) > 0:
            item = order[1]
            take = min(_cg_qty(order), debt[item])
            debt[item] -= take
            if debt[item] <= 0:
                debt.pop(item, None)
            _CG_TEL["repaid"] += take
            left = _cg_qty(order) - take
            if left > 0:
                out.append(["SELL", item, left])
            continue
        out.append(list(order))
    return out


def _cg_planned(tape, step, horizon):
    """Premium SELL units the tape still intends to post in the next turns."""
    planned = {}
    for ahead in range(1, horizon + 1):
        index = step + ahead
        if index >= len(tape):
            break
        for order in (tape[index] or {}).get("market") or []:
            if _cg_is_sell(order) and order[1] in _CG_PREMIUM:
                planned[order[1]] = planned.get(order[1], 0) + _cg_qty(order)
    return planned


def _cg_consolidate(obs, market):
    """Merge same-item SELL slots, highest price impact first.

    Quantity-conserving and price-neutral in isolation (each item has its own
    market inventory), but in a mirror it moves our units to a lower slot
    index than the clone's split orders, so we take the top rungs of the
    shared ladder.
    """
    sells, seen, others, n_sell = {}, [], [], 0
    for order in market:
        if _cg_is_sell(order):
            n_sell += 1
            item = order[1]
            if item not in sells:
                sells[item] = 0
                seen.append(item)
            sells[item] += _cg_qty(order)
        else:
            others.append(list(order))
    if n_sell < 2:
        return market
    merged = [["SELL", item, sells[item]] for item in seen if sells[item] > 0]
    merged.sort(key=lambda order: -_cg_impact(obs, order))
    return (merged + others)[:_CG_MAX_ORDERS]


def _cg_sweep(obs, action, market):
    """Sell whatever is still in the shed on the last actionable turn.

    Goods held at scoring are worth zero, so this cannot withhold anything and
    cannot be sell-pacing; it only uses market slots the tape left free.
    """
    shed = _cg_projected_shed(obs, action)
    claimed = {}
    for order in market:
        if _cg_is_sell(order):
            claimed[order[1]] = claimed.get(order[1], 0) + _cg_qty(order)
    rows = []
    for item in ("MELON", "WOOL", "MILK", "STRAWBERRY", "EGG", "TOMATO",
                 "CARROT", "FERTILIZER", "WHEAT"):
        left = int(shed.get(item, 0) or 0) - int(claimed.get(item, 0) or 0)
        if left > 0:
            rows.append((_cg_impact(obs, ["SELL", item, left]), item, left))
    if not rows:
        return market
    rows.sort(reverse=True)
    free = _CG_MAX_ORDERS - len(market)
    extra = []
    for _score, item, left in rows:
        if free <= 0:
            break
        extra.append(["SELL", item, left])
        free -= 1
    if not extra:
        return market
    _CG_TEL["swept"] += 1
    _CG_TEL["sweep_units"] += sum(order[2] for order in extra)
    return market + extra


def _cg_preempt(obs, action):
    seat = 1 if int(_v43_get(obs, "player", 0) or 0) == 1 else 0
    step = int(_v43_get(obs, "step", 0) or 0)
    state = _CG_STATE[seat]
    if step == 0 or step < state["last"]:
        state["debt"] = {}
    state["last"] = step
    debt = state["debt"]

    market = [list(order) for order in (action.get("market") or [])]
    touched = False

    # 1. Repay first, unconditionally.  A unit pulled forward while the gate
    #    was open must still be cancelled after the gate closes.
    if debt:
        market = _cg_repay(market, debt)
        touched = True

    gate_open = False
    if _CG_START <= step < _CG_STOP:
        gate_open = bool(_cg_clone_distance(obs) <= _CG_CLONE_MAX)
        if gate_open:
            _CG_TEL["gate_open_steps"] += 1
        else:
            _CG_TEL["gated_out"] += 1

    if gate_open:
        # 2. Consolidate our own SELL slots (frees slots and front-loads).
        if _CG_CONSOLIDATE:
            merged = _cg_consolidate(obs, market)
            if merged != market:
                _CG_TEL["consolidated"] += 1
                market = merged
                touched = True

        # 3. Borrow from the tape's future premium SELLs.
        if len(market) < _CG_MAX_ORDERS:
            route = _cg_selected_route(obs, _V43_CONFIG)
            tape = _V43_ROUTES.get(route) or []
            planned = _cg_planned(tape, step, _CG_HORIZON)
            for item in list(planned):
                planned[item] -= int(debt.get(item, 0) or 0)
                if planned[item] <= 0:
                    planned.pop(item, None)
            if planned:
                shed = _cg_projected_shed(obs, action)
                claimed = {}
                for order in market:
                    if _cg_is_sell(order):
                        claimed[order[1]] = claimed.get(order[1], 0) + _cg_qty(order)
                extra = []
                free = _CG_MAX_ORDERS - len(market)
                for item, want in sorted(planned.items(), key=lambda kv: -kv[1]):
                    if free <= 0:
                        break
                    available = (int(shed.get(item, 0) or 0)
                                 - int(claimed.get(item, 0) or 0))
                    qty = min(want, available, _CG_MAX_BATCH)
                    if qty < _CG_MIN_QTY:
                        continue
                    extra.append(["SELL", item, qty])
                    claimed[item] = claimed.get(item, 0) + qty
                    debt[item] = debt.get(item, 0) + qty
                    free -= 1
                if extra:
                    _CG_TEL["borrows"] += 1
                    _CG_TEL["units"] += sum(order[2] for order in extra)
                    market = (extra + market)[:_CG_MAX_ORDERS]
                    touched = True

    # 4. Terminal shed sweep: goods left in the shed score zero.
    if _CG_SWEEP and step >= _CG_SWEEP_STEP:
        swept = _cg_sweep(obs, action, market)
        if swept != market:
            market = swept
            touched = True

    if not touched:
        return action
    _CG_TEL["fired_steps"] += 1
    out = dict(action)
    out["market"] = market[:_CG_MAX_ORDERS]
    return out


def _cg_agent(obs, configuration=None):
    try:
        action = _V43_POLICY(obs, configuration)
    except Exception:
        seat = 1 if int(_v43_get(obs, "player", 0) or 0) == 1 else 0
        farms = list(_v43_get(obs, "farms", []) or [])
        farm = farms[seat] if seat < len(farms) else {}
        return {
            "farmer": ["PASS"],
            "hands": [["PASS"] for _ in (_v43_get(farm, "hands", []) or [])],
            "market": [],
        }
    try:
        return _cg_preempt(obs, action)
    except Exception:
        return action


# Rebinding `agent` does not move its dict insertion position, so the last
# callable inserted into this module is the fresh entrypoint below.  The
# rebind exists only so harnesses that call module.agent exercise the layer.
agent = _cg_agent


def _kaggriculture_knobs_entrypoint(obs, configuration=None):
    return _cg_agent(obs, configuration)
